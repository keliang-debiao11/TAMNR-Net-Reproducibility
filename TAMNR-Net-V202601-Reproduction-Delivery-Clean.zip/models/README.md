# Fresh V202601 checkpoints

The five `fold*_TAMNR-Net.joblib` files are the checkpoints produced by the
fresh GPU run on BACI HS92 V202601. Each bundle contains the fitted neural
state, fold-fitted scaler, entity encoder, feature order, configuration, and
calibration threshold.

These checkpoints belong to the `widest_relaxed_adjacent_year` sensitivity
protocol. They are not checkpoints for a strict rolling-origin validation.
The target-aware numerical reconstruction operates on saved predictions and
does not alter these neural checkpoints.
