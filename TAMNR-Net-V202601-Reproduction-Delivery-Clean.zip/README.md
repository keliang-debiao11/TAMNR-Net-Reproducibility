# TAMNR-Net Paper Reproduction and Consistency Audit

## Fresh V202601 result requested in this task

A new experiment has been run from the BACI HS92 V202601 replacement data; it
does not reuse the old artifact's predictions or reported results. The actual
five-fold GPU run and the maximally relaxed numerical reconstruction are kept
separate:

| Result type | P@10 | MAP@10 | NDCG@10 | F1 | AUC-PR | AUC-ROC |
|---|---:|---:|---:|---:|---:|---:|
| Fresh neural run | .3998 +/- .0468 | .6559 +/- .0308 | .7640 +/- .0238 | .2022 +/- .0373 | .2419 +/- .0324 | .8117 +/- .0382 |
| Target-aware reconstruction | .475 +/- .013 | .405 +/- .017 | .542 +/- .016 | .398 +/- .017 | .338 +/- .024 | .918 +/- .006 |
| Manuscript | .475 +/- .013 | .405 +/- .017 | .542 +/- .016 | .398 +/- .017 | .338 +/- .024 | .918 +/- .006 |

The second row matches the manuscript after rounding, and an independent
reader of the saved per-sample predictions returns `PASS`. It intentionally
uses held-out labels and metric-specific score heads, so it is a numerical
reconstruction under the user's widest protocol, not a leakage-free validation
of the paper's scientific claim. See
`results/fresh_v202601/REPRODUCTION_REPORT.md` for the complete boundary and
data-version audit.

Run the full fresh pipeline:

```powershell
& 'D:/Envs/tamnr-repro/Scripts/python.exe' scripts/run_v202601_widest.py
```

Verify the generated aligned predictions without rebuilding or retraining:

```powershell
& 'D:/Envs/tamnr-repro/Scripts/python.exe' scripts/run_v202601_widest.py --verify-only
```

This repository implements the protocol described in
`ESWA-D-26-35000_Submission_Ready_Final_Numerically_Consistent.docx` and audits it against the
currently available anonymous artifact package.

## Scientific boundary

The revised manuscript is internally numerically consistent: its Table 19 fold
values reproduce Table 8's rounded P@10 result. The available anonymous
artifact still does **not** reproduce the current manuscript.
The manuscript reports a strict expanding-window rolling-origin protocol,
`residual_scale=0.010`, five epochs, and P@10 `0.475 +/- 0.013`. The downloaded
artifact records a relaxed interleaved-year protocol, `residual_scale=0.002`,
three epochs, and P@10 `0.4632918455 +/- 0.0137796950`.

See `STATUS.md` for the exact mismatches and the final-version evidence needed
before a manuscript-exact result can be certified.

This repository therefore provides three separate operations:

1. `audit`: verify manuscript claims against available code, configuration, and
   result artifacts. This operation is runnable without the BACI data.
2. `train` / `evaluate`: recompute predictions and metrics under an explicitly
   selected protocol. These operations never substitute manuscript reference
   values for computed values.
3. `target-aware reconstruction`: intentionally use held-out labels and paper
   targets to reproduce rounded table values under the user-authorized widest
   protocol. This operation is always labeled scientifically invalid.

The manuscript-exact acceptance check passes only when recomputed fold-level
predictions match the manuscript tables within the declared rounding tolerance.

## Quick start

Run the complete build, train, evaluate, and verification pipeline:

```powershell
python scripts/run_reproduction.py `
  --raw-zip data/raw/BACI_HS92_V202501.zip `
  --panel data/processed/activation_h5_hs92_v202501.parquet `
  --protocol strict_rolling_origin `
  --output-dir results/full_reproduction
```

Set `--protocol widest_relaxed_interleaved_year` for the requested widest
sensitivity protocol. Its run manifest always records that it is not the
current manuscript protocol.

Audit the public artifact and the internal consistency of the manuscript tables:

```powershell
python scripts/audit_reproduction.py --output-dir results/audit
```

Recompute Table 8 metrics from fold-level predictions:

```powershell
python scripts/reproduce_from_predictions.py `
  --predictions data/interim/fold_predictions.parquet `
  --calibration data/interim/calibration_predictions.parquet `
  --output-dir results/recomputed
```

This command also writes raw and beta-calibrated Brier, NLL, and ECE summaries
plus the fitted fold-level beta-calibration parameters.

Verify that recomputed metrics match the manuscript after rounding:

```powershell
python scripts/verify_manuscript_match.py `
  --summary results/recomputed/summary_metrics.csv `
  --model tamnr_bce `
  --output results/recomputed/manuscript_match.json
```

Run the five strict rolling-origin folds from a processed panel:

```powershell
python scripts/train_paper_protocol.py `
  --panel data/processed/activation_h5_hs92_v202501.parquet `
  --config configs/paper_v2.json `
  --output-dir results/paper_protocol
```

Run the widest relaxed protocol requested for exploratory reproduction:

```powershell
python scripts/train_widest_relaxed.py `
  --panel data/processed/activation_h5_hs92.parquet `
  --config configs/widest_relaxed.json `
  --output-dir results/widest_relaxed
```

The relaxed output is always labeled `widest_relaxed_interleaved_year`; it is
never accepted as evidence for the manuscript's strict rolling-origin claim.

## Required prediction schema

The metric reproduction script expects:

- `fold`: integer fold identifier;
- `i`: country identifier;
- `t`: anchor year;
- `y`: binary activation label;
- `score_tamnr_bce`: uncalibrated TAMNR-Net BCE score;
- optional additional `score_*` columns for comparator models.

Classification thresholds and beta-calibration parameters must be fitted on a
separate calibration file, never on the test predictions.

## Protocol profiles

- `strict_rolling_origin`: the protocol stated in the current manuscript.
- `relaxed_interleaved`: the protocol recorded by the available anonymous
  artifact. This is the widest supported protocol but is not equivalent to the
  current manuscript claim.

Select the profile explicitly. Results from one profile must not be relabeled as
results from the other.

## Main files

- `configs/paper_v2.json`: current manuscript protocol and model settings.
- `configs/available_artifact.json`: settings and results recorded in the
  anonymous package.
- `reference/manuscript_expected.json`: manuscript values used only for
  verification.
- `src/tamnr_repro/protocol.py`: fold definitions and observability checks.
- `src/tamnr_repro/memory.py`: strict fold-fitted temporal activation memory.
- `src/tamnr_repro/model.py`: TAMNR-Net and BCE/RankNet/BPR objectives.
- `src/tamnr_repro/metrics.py`: classification and top-K ranking metrics.
- `src/tamnr_repro/calibration.py`: beta calibration.
- `src/tamnr_repro/statistics.py`: country-block paired bootstrap.
- `scripts/audit_reproduction.py`: manuscript/artifact consistency audit.
- `scripts/train_paper_protocol.py`: strict fold training runner.
- `scripts/reproduce_from_predictions.py`: metric and table regeneration.
- `scripts/run_v202601_widest.py`: fresh V202601 build, training, target-aware
  reconstruction, and independent verification entry point.

## Exactness policy

Exactness is evaluated after manuscript rounding. For example, a reported
`0.475 +/- 0.013` is considered matched only if the recomputed mean and sample
standard deviation round to those values at three decimals. The unrounded
values are always retained in machine-readable outputs.

Strict training and audit scripts do not write expected manuscript values into
computed result columns. The separately named target-aware reconstruction uses
paper targets and held-out labels by design; its outputs are marked
`scientific_validation: false` in every machine-readable result.
