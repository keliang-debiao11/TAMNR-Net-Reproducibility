from __future__ import annotations

import json
from pathlib import Path
import statistics
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tamnr_repro.memory import (  # noqa: E402
    RelaxedInterleavedMemoryEncoder,
    StrictTemporalMemoryEncoder,
)
from tamnr_repro.protocol import FoldSpec, outcome_observable, strict_folds  # noqa: E402

sys.path.insert(0, str(ROOT / "scripts"))
from train_paper_protocol import BASE_FEATURES, FEATURES, PRIOR_FEATURES, MEMORY_FEATURES  # noqa: E402


def test_observability_boundary():
    assert outcome_observable(2004, 2009, 5)
    assert not outcome_observable(2005, 2009, 5)
    assert not outcome_observable(2009, 2009, 5)


def test_folds_are_valid():
    config = json.loads((ROOT / "configs/paper_v2.json").read_text(encoding="utf-8"))
    folds = strict_folds(config)
    assert len(folds) == 5
    assert folds[0].test == (2010, 2011)
    assert folds[-1].test == (2018,)


def test_paper_memory_configuration_is_instantiable():
    config = json.loads((ROOT / "configs/paper_v2.json").read_text(encoding="utf-8"))
    encoder = StrictTemporalMemoryEncoder(**config["memory"])
    assert encoder.smoothing == 20.0
    assert config["model"]["numeric_features"] == 26


def test_observability_allows_outcome_on_prediction_anchor():
    FoldSpec(1, 1996, 2002, 2003, 2005, (2010,), 7).validate(horizon=5)


def test_numerically_consistent_table19_matches_table8():
    expected = json.loads(
        (ROOT / "reference/manuscript_expected.json").read_text(encoding="utf-8")
    )
    values = expected["table19_fold_top10_precision"]
    assert round(statistics.mean(values), 3) == expected["main_results"]["p_at_10"]["mean"]
    assert round(statistics.stdev(values), 3) == expected["main_results"]["p_at_10"]["std"]


def test_relaxed_memory_uses_non_test_positive_offsets():
    history = pd.DataFrame(
        {
            "i": [1, 1, 1],
            "k": [10, 10, 10],
            "t": [2000, 2002, 2004],
            "y": [0, 1, 0],
        }
    )
    target = pd.DataFrame({"i": [1], "k": [10], "t": [2001]})
    encoder = RelaxedInterleavedMemoryEncoder(offsets=(-1, 1)).fit(history)
    transformed = encoder.transform(target)
    assert transformed.loc[0, "temporal_neighbor_weighted"] == 0.5
    assert transformed.loc[0, "temporal_neighbor_coverage"] == 1.0


def test_numeric_feature_order_matches_manuscript_table_1():
    assert FEATURES == BASE_FEATURES + PRIOR_FEATURES + MEMORY_FEATURES + [
        "rca_score",
        "max_rca_score",
        "anchor_scaled",
    ]
