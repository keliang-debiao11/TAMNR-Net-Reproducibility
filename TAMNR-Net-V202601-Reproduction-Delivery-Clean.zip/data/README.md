# Data access

The full BACI dataset is intentionally not copied into this repository.

- Replacement release: [BACI HS92 V202601 mirror](https://github.com/phbelov/world-trade-app/releases/tag/data-v1)
- Local raw files: `D:/Datasets/BACI_HS92_V202601_parquet`
- Local DuckDB database: `D:/Datasets/TAMNR_V202601_fresh/tamnr_v202601.duckdb`
- Generated panel: `D:/Datasets/TAMNR_V202601_fresh/activation_panel_v202601.parquet`
- Download script: `scripts/download_baci_v202601_mirror.py`
- Panel builder: `scripts/build_panel_v202601.py`

The release contains 30 annual fact Parquets for 1995-2024 and two dimension
tables. The experiment reads 1995-2023 so every anchor through 2018 has a
five-year outcome.

The panel audit and file hashes are stored in
`results/fresh_v202601/panel_audit.json` and the root manifest.
