from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import torch
from torch.utils.data import DataLoader, TensorDataset


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tamnr_repro.memory import StrictTemporalMemoryEncoder  # noqa: E402
from tamnr_repro.metrics import best_f1_threshold  # noqa: E402
from tamnr_repro.model import TAMNRNet, seed_everything, weighted_bce  # noqa: E402
from tamnr_repro.protocol import load_config, strict_folds  # noqa: E402


BASE_FEATURES = [
    "rca_t", "rca_lag1", "rca_lag2", "rca_lag5", "log_export_t",
    "export_growth_1", "export_growth_3", "max_rca_history",
    "country_diversity", "product_ubiquity", "product_world_growth_3",
    "country_total_log", "product_total_log",
]
MEMORY_FEATURES = [
    "temporal_memory_logit", "temporal_memory_score", "temporal_neighbor_weighted",
    "temporal_neighbor_coverage", "cp_prior_logit", "prior_blend_logit",
]
PRIOR_FEATURES = [
    "country_activation_prior", "product_activation_prior",
    "country_product_activation_prior", "prior_blend",
]
FEATURES = BASE_FEATURES + PRIOR_FEATURES + MEMORY_FEATURES + [
    "rca_score", "max_rca_score", "anchor_scaled",
]


class EntityEncoder:
    def fit(self, frame: pd.DataFrame):
        self.country = {v: i + 1 for i, v in enumerate(sorted(frame["i"].unique()))}
        self.product = {v: i + 1 for i, v in enumerate(sorted(frame["k"].unique()))}
        self.year = {v: i + 1 for i, v in enumerate(sorted(frame["t"].unique()))}
        return self

    @property
    def sizes(self):
        return len(self.country) + 1, len(self.product) + 1, len(self.year) + 1

    def transform(self, frame):
        return (
            frame["i"].map(self.country).fillna(0).astype("int64").to_numpy(copy=True),
            frame["k"].map(self.product).fillna(0).astype("int64").to_numpy(copy=True),
            frame["t"].map(self.year).fillna(0).astype("int64").to_numpy(copy=True),
        )


def read_panel(path: Path) -> pd.DataFrame:
    if path.suffix.lower() in {".parquet", ".pq"}:
        return pd.read_parquet(path)
    return pd.read_csv(path)


def stratified_sample(frame: pd.DataFrame, max_rows: int, seed: int) -> pd.DataFrame:
    if len(frame) <= max_rows:
        return frame.copy()
    positives = frame[frame["y"].eq(1)]
    remaining = max(0, max_rows - len(positives))
    negatives = frame[frame["y"].eq(0)].sample(
        n=min(remaining, int((frame["y"] == 0).sum())), random_state=seed
    )
    return pd.concat([positives, negatives], ignore_index=True).sample(
        frac=1.0, random_state=seed
    ).reset_index(drop=True)


def add_fold_features(frame: pd.DataFrame, encoder: StrictTemporalMemoryEncoder, train_start: int, train_end: int):
    memory = encoder.transform(frame)
    out = frame.reset_index(drop=True).copy()
    for col in memory.columns:
        if col not in {"i", "k", "t"}:
            out[col] = memory[col].to_numpy()
    rca = np.maximum(out["rca_t"].to_numpy(dtype=float), 0.0)
    max_rca = np.maximum(out["max_rca_history"].to_numpy(dtype=float), 0.0)
    out["rca_score"] = rca / (1.0 + rca)
    out["max_rca_score"] = max_rca / (1.0 + max_rca)
    out["anchor_scaled"] = (out["t"].astype(float) - train_start) / max(1, train_end - train_start)
    out[FEATURES] = out[FEATURES].replace([np.inf, -np.inf], 0).fillna(0)
    return out


def tensor_data(frame, scaler, entities, include_y=True):
    x = scaler.transform(frame[FEATURES].to_numpy(dtype=float)).astype("float32")
    c, p, t = entities.transform(frame)
    arrays = {
        "x": x,
        "memory": frame["temporal_memory_logit"].to_numpy(dtype="float32", copy=True),
        "country": c,
        "product": p,
        "year": t,
    }
    if include_y:
        arrays["y"] = frame["y"].to_numpy(dtype="float32", copy=True)
    return arrays


def loader(data, batch_size, shuffle, include_y=True):
    tensors = [
        torch.from_numpy(data["x"]), torch.from_numpy(data["memory"]),
        torch.from_numpy(data["country"]), torch.from_numpy(data["product"]),
        torch.from_numpy(data["year"]),
    ]
    if include_y:
        tensors.append(torch.from_numpy(data["y"]))
    return DataLoader(TensorDataset(*tensors), batch_size=batch_size, shuffle=shuffle)


def predict(model, data, batch_size, device):
    result = []
    model.eval()
    with torch.no_grad():
        for xb, mb, cb, pb, tb in loader(data, batch_size, False, include_y=False):
            logits = model(
                xb.to(device), cb.to(device), pb.to(device), tb.to(device), mb.to(device)
            )
            result.append(torch.sigmoid(logits).cpu().numpy())
    return np.concatenate(result)


def fit_bce(model, train, validation, config, device):
    y = train["y"]
    pos = float(y.sum())
    neg = float(len(y) - pos)
    positive_weight = min(float(config["positive_weight_cap"]), neg / max(pos, 1.0))
    optimizer = torch.optim.AdamW(
        model.parameters(), lr=config["learning_rate"], weight_decay=config["weight_decay"]
    )
    best_loss = float("inf")
    best_state = None
    best_epoch = 0
    for epoch in range(1, int(config["epochs"]) + 1):
        model.train()
        for xb, mb, cb, pb, tb, yb in loader(train, config["batch_size"], True):
            optimizer.zero_grad(set_to_none=True)
            logits = model(
                xb.to(device), cb.to(device), pb.to(device), tb.to(device), mb.to(device)
            )
            loss = weighted_bce(logits, yb.to(device), positive_weight)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), config["gradient_clip_norm"])
            optimizer.step()
        losses = []
        model.eval()
        with torch.no_grad():
            for xb, mb, cb, pb, tb, yb in loader(validation, config["batch_size"] * 4, False):
                logits = model(
                    xb.to(device), cb.to(device), pb.to(device), tb.to(device), mb.to(device)
                )
                losses.append(float(weighted_bce(logits, yb.to(device), positive_weight).cpu()))
        val_loss = float(np.mean(losses))
        if val_loss < best_loss:
            best_loss = val_loss
            best_epoch = epoch
            best_state = {k: v.detach().cpu().clone() for k, v in model.state_dict().items()}
    model.load_state_dict(best_state)
    return best_loss, best_epoch


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--panel", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/paper_v2.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    cfg = load_config(args.config)
    panel = read_panel(args.panel).reset_index(drop=True)
    required = set(BASE_FEATURES + ["i", "k", "t", "y"])
    missing = required.difference(panel.columns)
    if missing:
        raise ValueError(f"Processed panel is missing: {sorted(missing)}")
    panel["_row_id"] = np.arange(len(panel), dtype=np.int64)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    predictions = []
    calibration_predictions = []
    logs = []
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    for spec in strict_folds(cfg):
        start = time.perf_counter()
        seed_everything(spec.seed)
        train_full = panel[panel["t"].between(spec.train_start, spec.train_end)].copy()
        validation_full = panel[panel["t"].eq(spec.validation)].copy()
        calibration = panel[panel["t"].eq(spec.calibration)].copy()
        test = panel[panel["t"].isin(spec.test)].copy()
        if not all(len(x) for x in [train_full, validation_full, calibration, test]):
            raise ValueError(f"Fold {spec.fold} has an empty partition")

        memory = StrictTemporalMemoryEncoder(**cfg["memory"]).fit(train_full)
        train_sample = stratified_sample(
            train_full, cfg["model"]["max_train_rows"], spec.seed
        )
        validation_sample = stratified_sample(
            validation_full, cfg["model"]["max_validation_rows"], spec.seed + 1
        )
        train = add_fold_features(
            train_sample,
            memory, spec.train_start, spec.train_end,
        )
        validation = add_fold_features(
            validation_sample,
            memory, spec.train_start, spec.train_end,
        )
        calibration_fe = add_fold_features(calibration, memory, spec.train_start, spec.train_end)
        test_fe = add_fold_features(test, memory, spec.train_start, spec.train_end)

        scaler = StandardScaler().fit(train[FEATURES].to_numpy(dtype=float))
        entities = EntityEncoder().fit(train_full)
        train_data = tensor_data(train, scaler, entities)
        validation_data = tensor_data(validation, scaler, entities)
        calibration_data = tensor_data(calibration_fe, scaler, entities, include_y=False)
        test_data = tensor_data(test_fe, scaler, entities, include_y=False)
        n_c, n_p, n_t = entities.sizes
        model = TAMNRNet(
            len(FEATURES), n_c, n_p, n_t,
            hidden_dim=cfg["model"]["hidden_dim"],
            embedding_dim=cfg["model"]["embedding_dim"],
            year_embedding_dim=cfg["model"]["year_embedding_dim"],
            dropout=cfg["model"]["dropout"],
            residual_scale=cfg["model"]["residual_scale"],
            temperature_min=cfg["model"]["memory_temperature_min"],
            temperature_max=cfg["model"]["memory_temperature_max"],
        ).to(device)
        best_loss, best_epoch = fit_bce(
            model, train_data, validation_data, cfg["model"], device
        )
        cal_score = predict(model, calibration_data, cfg["model"]["batch_size"] * 8, device)
        test_score = predict(model, test_data, cfg["model"]["batch_size"] * 8, device)
        threshold, cal_f1 = best_f1_threshold(calibration_fe["y"], cal_score)
        cal_out = calibration_fe[["i", "k", "t", "y"]].copy()
        cal_out["fold"] = spec.fold
        cal_out["score_tamnr_bce"] = cal_score
        calibration_predictions.append(cal_out)
        out = test_fe[["i", "k", "t", "y"]].copy()
        out["fold"] = spec.fold
        out["score_tamnr_bce"] = test_score
        out["threshold_tamnr_bce"] = threshold
        predictions.append(out)
        artifact = {
            "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
            "scaler": scaler,
            "entities": entities,
            "features": FEATURES,
            "config": cfg,
            "fold": spec.fold,
            "protocol": "strict_rolling_origin",
            "temporal_memory": memory,
        }
        joblib.dump(artifact, args.output_dir / f"fold{spec.fold}_TAMNR-Net-BCE.joblib")
        np.savez_compressed(
            args.output_dir / f"fold{spec.fold}_sampled_row_ids.npz",
            train=train_sample["_row_id"].to_numpy(dtype=np.int64),
            validation=validation_sample["_row_id"].to_numpy(dtype=np.int64),
        )
        logs.append(
            {
                "fold": spec.fold,
                "seed": spec.seed,
                "train_anchors": [spec.train_start, spec.train_end],
                "validation_anchor": spec.validation,
                "calibration_anchor": spec.calibration,
                "test_anchors": list(spec.test),
                "train_rows_full": len(train_full),
                "train_rows_sampled": len(train_sample),
                "validation_rows_full": len(validation_full),
                "validation_rows_sampled": len(validation_sample),
                "calibration_rows": len(calibration),
                "test_rows": len(test),
                "best_validation_loss": best_loss,
                "best_epoch": best_epoch,
                "calibration_threshold": threshold,
                "calibration_f1": cal_f1,
                "parameter_count": sum(p.numel() for p in model.parameters()),
                "seconds": time.perf_counter() - start,
                "device": str(device),
                "protocol": "strict_rolling_origin",
            }
        )

    pd.concat(predictions, ignore_index=True).to_parquet(
        args.output_dir / "fold_predictions.parquet", index=False
    )
    pd.concat(calibration_predictions, ignore_index=True).to_parquet(
        args.output_dir / "calibration_predictions.parquet", index=False
    )
    (args.output_dir / "training_log.json").write_text(
        json.dumps(logs, indent=2), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
