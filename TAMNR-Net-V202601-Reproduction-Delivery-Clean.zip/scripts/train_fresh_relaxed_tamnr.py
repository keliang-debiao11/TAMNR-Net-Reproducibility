#!/usr/bin/env python3
"""Fresh GPU training on BACI V202601 with an explicit relaxed protocol."""

from __future__ import annotations

import argparse
import json
import statistics
import sys
import time
from pathlib import Path

import duckdb
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import StandardScaler
import torch


ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts")]

from tamnr_repro.metrics import (  # noqa: E402
    best_f1_threshold,
    classification_metrics,
    group_ranking_metrics,
)
from tamnr_repro.model import TAMNRNet, seed_everything  # noqa: E402
from train_paper_protocol import (  # noqa: E402
    EntityEncoder,
    FEATURES,
    fit_bce,
    predict,
    tensor_data,
)


FOLDS = [
    (1, (2010, 2011), 20261005),
    (2, (2012, 2013), 20261006),
    (3, (2014, 2015), 20261007),
    (4, (2016, 2017), 20261008),
    (5, (2018,), 20261009),
]
OBSOLETE_COUNTRIES = (58, 530, 711, 736, 849, 891)


def offset_condition(offsets: tuple[int, ...]) -> str:
    return " OR ".join(f"h.t = x.t + ({offset})" for offset in offsets)


def stratified_target_table(
    connection: duckdb.DuckDBPyConnection,
    source_query: str,
    table_name: str,
    max_rows: int,
    seed: int,
) -> None:
    positive_count = int(
        connection.execute(f"SELECT COUNT(*) FROM ({source_query}) s WHERE y=1").fetchone()[0]
    )
    negative_limit = max(0, max_rows - positive_count)
    connection.execute(
        f"""
        CREATE OR REPLACE TEMP TABLE {table_name} AS
        SELECT * FROM ({source_query}) positives WHERE y = 1
        UNION ALL
        SELECT * EXCLUDE (sample_order)
        FROM (
            SELECT *, HASH(i, k, t, {seed}) AS sample_order
            FROM ({source_query}) negatives
            WHERE y = 0
            ORDER BY sample_order
            LIMIT {negative_limit}
        ) sampled_negatives
        """
    )


def prepare_priors(connection: duckdb.DuckDBPyConnection) -> float:
    prevalence = float(connection.execute("SELECT AVG(y::DOUBLE) FROM history_f").fetchone()[0])
    connection.execute(
        f"""
        CREATE OR REPLACE TEMP TABLE country_prior AS
        SELECT i, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_i
        FROM history_f GROUP BY i
        """
    )
    connection.execute(
        f"""
        CREATE OR REPLACE TEMP TABLE product_prior AS
        SELECT k, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_k
        FROM history_f GROUP BY k
        """
    )
    connection.execute(
        f"""
        CREATE OR REPLACE TEMP TABLE cp_prior AS
        SELECT i, k, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_cp
        FROM history_f GROUP BY i, k
        """
    )
    return prevalence


def feature_frame(
    connection: duckdb.DuckDBPyConnection,
    target_table: str,
    prefix: str,
    offsets: tuple[int, ...],
    prevalence: float,
    neighbor_weight: float,
) -> pd.DataFrame:
    connection.execute(
        f"""
        CREATE OR REPLACE TEMP TABLE neighbor_{prefix} AS
        SELECT
            x.i,
            x.k,
            x.t,
            SUM((1.0 / (ABS(h.t - x.t) + 0.5)) * h.y)
                / SUM(1.0 / (ABS(h.t - x.t) + 0.5)) AS neighbor,
            COUNT(*) AS neighbor_count
        FROM {target_table} x
        JOIN history_f h
          ON x.i = h.i AND x.k = h.k
         AND ({offset_condition(offsets)})
        GROUP BY x.i, x.k, x.t
        """
    )
    prior_weight = 1.0 - neighbor_weight
    query = f"""
        WITH priors AS (
            SELECT
                x.*,
                COALESCE(ci.q_i, {prevalence}) AS country_activation_prior,
                COALESCE(pk.q_k, {prevalence}) AS product_activation_prior,
                COALESCE(cp.q_cp, {prevalence}) AS country_product_activation_prior
            FROM {target_table} x
            LEFT JOIN country_prior ci USING (i)
            LEFT JOIN product_prior pk USING (k)
            LEFT JOIN cp_prior cp USING (i, k)
        ),
        memory AS (
            SELECT
                p.*,
                0.50 * country_product_activation_prior
                    + 0.25 * country_activation_prior
                    + 0.25 * product_activation_prior AS prior_blend,
                COALESCE(
                    n.neighbor,
                    0.50 * country_product_activation_prior
                        + 0.25 * country_activation_prior
                        + 0.25 * product_activation_prior
                ) AS temporal_neighbor_weighted,
                CASE WHEN n.neighbor_count > 0 THEN 1.0 ELSE 0.0 END
                    AS temporal_neighbor_coverage
            FROM priors p
            LEFT JOIN neighbor_{prefix} n USING (i, k, t)
        ),
        scored AS (
            SELECT
                *,
                {neighbor_weight} * temporal_neighbor_weighted
                    + {prior_weight} * prior_blend AS temporal_memory_score
            FROM memory
        )
        SELECT
            i, k, t, y,
            rca_t, rca_lag1, rca_lag2, rca_lag5,
            log_export_t, export_growth_1, export_growth_3,
            max_rca_history, country_diversity, product_ubiquity,
            product_world_growth_3, country_total_log, product_total_log,
            country_activation_prior, product_activation_prior,
            country_product_activation_prior, prior_blend,
            LN(
                GREATEST(1e-6, LEAST(1.0 - 1e-6, temporal_memory_score))
                / (1.0 - GREATEST(1e-6, LEAST(1.0 - 1e-6, temporal_memory_score)))
            ) AS temporal_memory_logit,
            temporal_memory_score,
            temporal_neighbor_weighted,
            temporal_neighbor_coverage,
            LN(
                GREATEST(1e-6, LEAST(1.0 - 1e-6, country_product_activation_prior))
                / (1.0 - GREATEST(1e-6, LEAST(1.0 - 1e-6, country_product_activation_prior)))
            ) AS cp_prior_logit,
            LN(
                GREATEST(1e-6, LEAST(1.0 - 1e-6, prior_blend))
                / (1.0 - GREATEST(1e-6, LEAST(1.0 - 1e-6, prior_blend)))
            ) AS prior_blend_logit,
            rca_t / (1.0 + rca_t) AS rca_score,
            max_rca_history / (1.0 + max_rca_history) AS max_rca_score,
            (t - 1996.0) / (2018.0 - 1996.0) AS anchor_scaled
        FROM scored
    """
    frame = connection.execute(query).df()
    frame[FEATURES] = frame[FEATURES].replace([np.inf, -np.inf], 0.0).fillna(0.0)
    return frame


def entity_encoder(connection: duckdb.DuckDBPyConnection) -> EntityEncoder:
    encoder = EntityEncoder()
    countries = [
        row[0]
        for row in connection.execute(
            "SELECT DISTINCT i FROM history_f ORDER BY i"
        ).fetchall()
    ]
    products = [
        row[0]
        for row in connection.execute(
            "SELECT DISTINCT k FROM history_f ORDER BY k"
        ).fetchall()
    ]
    years = [
        row[0]
        for row in connection.execute(
            "SELECT DISTINCT t FROM history_f ORDER BY t"
        ).fetchall()
    ]
    encoder.country = {value: index + 1 for index, value in enumerate(countries)}
    encoder.product = {value: index + 1 for index, value in enumerate(products)}
    encoder.year = {value: index + 1 for index, value in enumerate(years)}
    return encoder


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database",
        type=Path,
        default=Path(r"D:\Datasets\TAMNR_V202601_fresh\tamnr_v202601.duckdb"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(r"D:\Datasets\TAMNR_V202601_fresh\fresh_relaxed_training"),
    )
    parser.add_argument("--offsets", default="-3,-2,-1,1,2,3")
    parser.add_argument("--neighbor-weight", type=float, default=1.0)
    parser.add_argument("--max-train-rows", type=int, default=900_000)
    parser.add_argument("--max-validation-rows", type=int, default=220_000)
    parser.add_argument("--max-calibration-rows", type=int, default=220_000)
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--batch-size", type=int, default=8192)
    parser.add_argument("--folds", default="1,2,3,4,5")
    args = parser.parse_args()

    offsets = tuple(int(value) for value in args.offsets.split(",") if value)
    selected_folds = {int(value) for value in args.folds.split(",") if value}
    args.output_dir.mkdir(parents=True, exist_ok=True)
    connection = duckdb.connect(str(args.database))
    connection.execute("SET threads=16")
    connection.execute("SET memory_limit='64GB'")
    excluded = ", ".join(str(code) for code in OBSOLETE_COUNTRIES)
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model_config = {
        "hidden_dim": 128,
        "embedding_dim": 16,
        "year_embedding_dim": 4,
        "dropout": 0.08,
        "residual_scale": 0.010,
        "temperature_min": 0.25,
        "temperature_max": 4.0,
        "learning_rate": 0.001,
        "weight_decay": 0.0001,
        "batch_size": args.batch_size,
        "epochs": args.epochs,
        "positive_weight_cap": 80.0,
        "gradient_clip_norm": 3.0,
    }
    fold_metrics = []
    training_logs = []

    for fold, test_years, seed in FOLDS:
        if fold not in selected_folds:
            continue
        started = time.perf_counter()
        seed_everything(seed)
        years = ", ".join(str(year) for year in test_years)
        print(f"[fold {fold}] preparing SQL features", flush=True)
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP VIEW eligible AS
            SELECT * FROM activation_panel
            WHERE i NOT IN ({excluded})
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE history_f AS
            SELECT i, k, t, CAST(y AS DOUBLE) AS y
            FROM eligible WHERE t NOT IN ({years})
            """
        )
        prevalence = prepare_priors(connection)
        split_expression = f"HASH(i, k, t, {seed}) % 1000"
        train_source = (
            f"SELECT * FROM eligible WHERE t NOT IN ({years}) "
            f"AND {split_expression} >= 200"
        )
        validation_source = (
            f"SELECT * FROM eligible WHERE t NOT IN ({years}) "
            f"AND {split_expression} BETWEEN 100 AND 199"
        )
        calibration_source = (
            f"SELECT * FROM eligible WHERE t NOT IN ({years}) "
            f"AND {split_expression} < 100"
        )
        stratified_target_table(
            connection, train_source, "train_target", args.max_train_rows, seed + 11
        )
        stratified_target_table(
            connection,
            validation_source,
            "validation_target",
            args.max_validation_rows,
            seed + 12,
        )
        stratified_target_table(
            connection,
            calibration_source,
            "calibration_target",
            args.max_calibration_rows,
            seed + 13,
        )
        connection.execute(
            f"CREATE OR REPLACE TEMP TABLE test_target AS SELECT * FROM eligible WHERE t IN ({years})"
        )
        train = feature_frame(
            connection, "train_target", "train", offsets, prevalence, args.neighbor_weight
        )
        validation = feature_frame(
            connection,
            "validation_target",
            "validation",
            offsets,
            prevalence,
            args.neighbor_weight,
        )
        calibration = feature_frame(
            connection,
            "calibration_target",
            "calibration",
            offsets,
            prevalence,
            args.neighbor_weight,
        )
        test = feature_frame(
            connection, "test_target", "test", offsets, prevalence, args.neighbor_weight
        )
        scaler = StandardScaler().fit(train[FEATURES].to_numpy(dtype=float))
        entities = entity_encoder(connection)
        train_data = tensor_data(train, scaler, entities)
        validation_data = tensor_data(validation, scaler, entities)
        calibration_data = tensor_data(calibration, scaler, entities, include_y=False)
        test_data = tensor_data(test, scaler, entities, include_y=False)
        n_countries, n_products, n_years = entities.sizes
        model = TAMNRNet(
            len(FEATURES),
            n_countries,
            n_products,
            n_years,
            hidden_dim=model_config["hidden_dim"],
            embedding_dim=model_config["embedding_dim"],
            year_embedding_dim=model_config["year_embedding_dim"],
            dropout=model_config["dropout"],
            residual_scale=model_config["residual_scale"],
            temperature_min=model_config["temperature_min"],
            temperature_max=model_config["temperature_max"],
        ).to(device)
        print(f"[fold {fold}] training on {len(train):,} rows with {device}", flush=True)
        best_loss, best_epoch = fit_bce(
            model, train_data, validation_data, model_config, device
        )
        calibration_score = predict(
            model, calibration_data, model_config["batch_size"] * 8, device
        )
        test_score = predict(model, test_data, model_config["batch_size"] * 8, device)
        threshold, calibration_f1 = best_f1_threshold(calibration["y"], calibration_score)
        prediction = test[["i", "k", "t", "y", "temporal_memory_score"]].copy()
        prediction["fold"] = fold
        prediction["score_tamnr_bce"] = test_score
        prediction["threshold_tamnr_bce"] = threshold
        prediction_path = args.output_dir / f"fold{fold}_predictions.parquet"
        prediction.to_parquet(prediction_path, index=False)
        ranking, _ = group_ranking_metrics(prediction, "score_tamnr_bce", k=10)
        point = classification_metrics(prediction["y"], test_score, threshold)
        fold_metrics.append(
            {
                "fold": fold,
                "p_at_10": ranking["precision_at_10"],
                "map_at_10": ranking["map_at_10"],
                "ndcg_at_10": ranking["ndcg_at_10"],
                "f1": point["f1"],
                "auc_pr": point["auc_pr"],
                "auc_roc": point["auc_roc"],
            }
        )
        artifact = {
            "model_name": "Temporal Activation-Memory Neural Ranking Network",
            "abbreviation": "TAMNR-Net",
            "state_dict": {key: value.detach().cpu() for key, value in model.state_dict().items()},
            "scaler": scaler,
            "entities": entities,
            "features": FEATURES,
            "fold": fold,
            "test_years": test_years,
            "seed": seed,
            "protocol": "fresh_relaxed_interleaved_year",
            "offsets": offsets,
            "neighbor_weight": args.neighbor_weight,
            "model_config": model_config,
        }
        joblib.dump(artifact, args.output_dir / f"fold{fold}_TAMNR-Net.joblib")
        log = {
            "fold": fold,
            "seed": seed,
            "test_years": list(test_years),
            "train_rows": len(train),
            "validation_rows": len(validation),
            "calibration_rows": len(calibration),
            "test_rows": len(test),
            "train_prevalence": prevalence,
            "best_validation_loss": best_loss,
            "best_epoch": best_epoch,
            "calibration_threshold": threshold,
            "calibration_f1": calibration_f1,
            "parameter_count": sum(parameter.numel() for parameter in model.parameters()),
            "elapsed_seconds": time.perf_counter() - started,
            "device": str(device),
        }
        training_logs.append(log)
        print(f"[fold {fold}] metrics={fold_metrics[-1]}", flush=True)

    summary = {}
    for metric in ("p_at_10", "map_at_10", "ndcg_at_10", "f1", "auc_pr", "auc_roc"):
        values = [row[metric] for row in fold_metrics]
        summary[metric] = {
            "mean": statistics.mean(values),
            "std": statistics.stdev(values) if len(values) > 1 else 0.0,
        }
    result = {
        "protocol": "fresh_relaxed_interleaved_year",
        "data_version": "BACI HS92 V202601",
        "offsets": offsets,
        "neighbor_weight": args.neighbor_weight,
        "fold_metrics": fold_metrics,
        "summary": summary,
        "training_logs": training_logs,
    }
    (args.output_dir / "fresh_training_results.json").write_text(
        json.dumps(result, indent=2), encoding="utf-8"
    )
    connection.close()
    print(json.dumps(result, indent=2), flush=True)


if __name__ == "__main__":
    main()
