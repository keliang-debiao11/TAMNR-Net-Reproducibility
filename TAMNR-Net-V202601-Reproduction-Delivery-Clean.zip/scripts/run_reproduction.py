from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time


ROOT = Path(__file__).resolve().parents[1]


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest().upper()


def run(command: list[str]) -> None:
    print("RUN", subprocess.list2cmdline(command), flush=True)
    subprocess.run(command, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--raw-zip", type=Path)
    parser.add_argument("--panel", type=Path, required=True)
    parser.add_argument(
        "--protocol",
        choices=["strict_rolling_origin", "widest_relaxed_interleaved_year"],
        default="strict_rolling_origin",
    )
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()

    started = time.time()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if not args.panel.exists():
        if args.raw_zip is None or not args.raw_zip.exists():
            raise FileNotFoundError(
                "Supply --raw-zip when --panel does not already exist"
            )
        run(
            [
                sys.executable,
                str(ROOT / "scripts/build_panel.py"),
                "--zip",
                str(args.raw_zip),
                "--output",
                str(args.panel),
            ]
        )

    training_dir = args.output_dir / "training"
    metrics_dir = args.output_dir / "metrics"
    if args.protocol == "strict_rolling_origin":
        config = ROOT / "configs/paper_v2.json"
        trainer = ROOT / "scripts/train_paper_protocol.py"
    else:
        config = ROOT / "configs/widest_relaxed.json"
        trainer = ROOT / "scripts/train_widest_relaxed.py"

    run(
        [
            sys.executable,
            str(trainer),
            "--panel",
            str(args.panel),
            "--config",
            str(config),
            "--output-dir",
            str(training_dir),
        ]
    )
    run(
        [
            sys.executable,
            str(ROOT / "scripts/reproduce_from_predictions.py"),
            "--predictions",
            str(training_dir / "fold_predictions.parquet"),
            "--calibration",
            str(training_dir / "calibration_predictions.parquet"),
            "--output-dir",
            str(metrics_dir),
        ]
    )

    verification_status = "NOT_MANUSCRIPT_PROTOCOL"
    verification_exit_code = None
    if args.protocol == "strict_rolling_origin":
        completed = subprocess.run(
            [
                sys.executable,
                str(ROOT / "scripts/verify_manuscript_match.py"),
                "--summary",
                str(metrics_dir / "summary_metrics.csv"),
                "--model",
                "tamnr_bce",
                "--output",
                str(args.output_dir / "manuscript_match.json"),
            ],
            check=False,
        )
        verification_exit_code = int(completed.returncode)
        verification_status = "PASS" if completed.returncode == 0 else "FAIL"

    manifest = {
        "protocol": args.protocol,
        "protocol_is_current_manuscript_protocol": (
            args.protocol == "strict_rolling_origin"
        ),
        "panel": str(args.panel.resolve()),
        "panel_sha256": sha256(args.panel),
        "raw_zip": (
            str(args.raw_zip.resolve())
            if args.raw_zip is not None and args.raw_zip.exists()
            else None
        ),
        "raw_zip_sha256": (
            sha256(args.raw_zip)
            if args.raw_zip is not None and args.raw_zip.exists()
            else None
        ),
        "config": str(config.resolve()),
        "config_sha256": sha256(config),
        "verification_status": verification_status,
        "verification_exit_code": verification_exit_code,
        "elapsed_seconds": time.time() - started,
    }
    (args.output_dir / "run_manifest.json").write_text(
        json.dumps(manifest, indent=2), encoding="utf-8"
    )
    print(json.dumps(manifest, indent=2))
    return 0 if verification_status in {"PASS", "NOT_MANUSCRIPT_PROTOCOL"} else 2


if __name__ == "__main__":
    raise SystemExit(main())
