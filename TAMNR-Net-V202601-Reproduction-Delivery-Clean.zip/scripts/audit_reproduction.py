from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
import statistics
import sys


ROOT = Path(__file__).resolve().parents[1]


def read_json(path: Path) -> dict:
    return json.loads(path.read_text(encoding="utf-8"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--output-dir", type=Path, default=ROOT / "results/audit")
    parser.add_argument(
        "--artifact-summary",
        type=Path,
        default=ROOT.parent
        / "TAMNR-Net-Reproduction-840D-current/package/external/stage3_validation/main_summary.csv",
    )
    parser.add_argument("--allow-mismatch", action="store_true")
    args = parser.parse_args()

    expected = read_json(ROOT / "reference/manuscript_expected.json")
    available = read_json(ROOT / "configs/available_artifact.json")
    paper = read_json(ROOT / "configs/paper_v2.json")

    fold_values = expected["table19_fold_top10_precision"]
    fold_mean = statistics.mean(fold_values)
    fold_sd = statistics.stdev(fold_values)
    manuscript_main = expected["main_results"]["p_at_10"]
    snapshot_path = ROOT / "evidence/public_artifact_main_summary.csv"
    with snapshot_path.open("r", encoding="utf-8", newline="") as handle:
        artifact_rows = list(csv.DictReader(handle))
    artifact_row = next(row for row in artifact_rows if row["model"] == "TAMNR-Net")
    artifact_main = {
        "mean_precision_at_10_mean": float(artifact_row["mean_precision_at_10_mean"]),
        "mean_precision_at_10_std": float(artifact_row["mean_precision_at_10_std"]),
    }

    checks = [
        {
            "id": "protocol_name",
            "expected": paper["protocol"]["name"],
            "observed": available["protocol"],
            "match": paper["protocol"]["name"] == available["protocol"],
        },
        {
            "id": "dataset_revision",
            "expected": paper["dataset"]["name"],
            "observed": available["dataset_revision"],
            "match": "V202501" in available["dataset_revision"],
        },
        {
            "id": "residual_scale",
            "expected": paper["model"]["residual_scale"],
            "observed": available["residual_scale"],
            "match": paper["model"]["residual_scale"] == available["residual_scale"],
        },
        {
            "id": "epochs",
            "expected": paper["model"]["epochs"],
            "observed": available["epochs"],
            "match": paper["model"]["epochs"] == available["epochs"],
        },
        {
            "id": "main_p10_rounded",
            "expected": manuscript_main["mean"],
            "observed": round(artifact_main["mean_precision_at_10_mean"], 3),
            "match": round(artifact_main["mean_precision_at_10_mean"], 3)
            == manuscript_main["mean"],
        },
        {
            "id": "table19_vs_table8_mean",
            "expected": manuscript_main["mean"],
            "observed": fold_mean,
            "match": round(fold_mean, 3) == manuscript_main["mean"],
        },
        {
            "id": "table19_vs_table8_sd",
            "expected": manuscript_main["std"],
            "observed": fold_sd,
            "match": round(fold_sd, 3) == manuscript_main["std"],
        },
    ]

    internal_checks = [c for c in checks if c["id"].startswith("table19_vs_table8")]
    artifact_checks = [c for c in checks if c not in internal_checks]
    result = {
        "status": "PASS" if all(c["match"] for c in checks) else "FAIL",
        "manuscript_internal_consistency": (
            "PASS" if all(c["match"] for c in internal_checks) else "FAIL"
        ),
        "public_artifact_reproduction": (
            "PASS" if all(c["match"] for c in artifact_checks) else "FAIL"
        ),
        "checks": checks,
        "key_finding": (
            "The numerically consistent manuscript now has Table 19 fold values that round "
            "to Table 8's 0.475 +/- 0.013. The available public artifact is still a "
            "different relaxed experiment and does not reproduce the current manuscript."
        ),
        "live_artifact_summary_found": args.artifact_summary.exists(),
        "evidence_snapshot_found": snapshot_path.exists(),
        "evidence_snapshot": str(ROOT / "evidence/public_artifact_main_summary.csv"),
    }
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "audit.json").write_text(
        json.dumps(result, indent=2, ensure_ascii=False), encoding="utf-8"
    )
    lines = [
        "# TAMNR-Net Reproduction Consistency Audit",
        "",
        f"Status: **{result['status']}**",
        "",
        f"Manuscript internal consistency: **{result['manuscript_internal_consistency']}**",
        "",
        f"Public artifact reproduction: **{result['public_artifact_reproduction']}**",
        "",
        result["key_finding"],
        "",
        "| Check | Expected | Observed | Match |",
        "| --- | --- | --- | --- |",
    ]
    for check in checks:
        lines.append(
            f"| {check['id']} | {check['expected']} | {check['observed']} | {check['match']} |"
        )
    (args.output_dir / "audit.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(json.dumps(result, indent=2, ensure_ascii=False))
    if result["status"] == "FAIL" and not args.allow_mismatch:
        return 2
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
