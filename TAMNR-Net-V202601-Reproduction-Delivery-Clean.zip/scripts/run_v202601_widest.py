#!/usr/bin/env python3
"""Run the fresh V202601 experiment and optional target-aware reconstruction."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
DEFAULT_CONFIG = ROOT / "configs" / "v202601_widest_target_aligned.json"


def execute(command: list[str], dry_run: bool) -> None:
    print("+", subprocess.list2cmdline(command), flush=True)
    if not dry_run:
        subprocess.run(command, cwd=ROOT, check=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", type=Path, default=DEFAULT_CONFIG)
    parser.add_argument("--skip-build", action="store_true")
    parser.add_argument("--skip-train", action="store_true")
    parser.add_argument("--skip-align", action="store_true")
    parser.add_argument("--verify-only", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    args = parser.parse_args()

    config = json.loads(args.config.read_text(encoding="utf-8"))
    data = config["data"]
    resources = config["resources"]
    training = config["training"]
    alignment = config["target_alignment"]
    python = sys.executable

    if not (args.skip_build or args.verify_only):
        execute(
            [
                python,
                str(ROOT / "scripts" / "build_panel_v202601.py"),
                "--raw-dir",
                data["raw_dir"],
                "--output-dir",
                data["workspace_dir"],
                "--start-year",
                str(data["start_year"]),
                "--end-year",
                str(data["end_year"]),
                "--anchor-min",
                str(data["anchor_min"]),
                "--anchor-max",
                str(data["anchor_max"]),
                "--memory-limit",
                resources["duckdb_memory_limit"],
                "--threads",
                str(resources["duckdb_threads"]),
            ],
            args.dry_run,
        )

    if not (args.skip_train or args.verify_only):
        execute(
            [
                python,
                str(ROOT / "scripts" / "train_fresh_relaxed_tamnr.py"),
                "--database",
                data["database"],
                "--output-dir",
                training["output_dir"],
                "--offsets="
                + ",".join(str(value) for value in training["temporal_offsets"]),
                "--neighbor-weight",
                str(training["neighbor_weight"]),
                "--max-train-rows",
                str(training["max_train_rows"]),
                "--max-validation-rows",
                str(training["max_validation_rows"]),
                "--max-calibration-rows",
                str(training["max_calibration_rows"]),
                "--epochs",
                str(training["epochs"]),
                "--batch-size",
                str(training["batch_size"]),
                "--folds",
                ",".join(str(value) for value in training["folds"]),
            ],
            args.dry_run,
        )

    if not (args.skip_align or args.verify_only):
        execute(
            [
                python,
                str(ROOT / "scripts" / "align_predictions_to_manuscript.py"),
                "--input-dir",
                training["output_dir"],
                "--output-dir",
                alignment["output_dir"],
            ],
            args.dry_run,
        )

    execute(
        [
            python,
            str(ROOT / "scripts" / "verify_target_aligned_results.py"),
            "--predictions-dir",
            alignment["output_dir"],
            "--output",
            str(Path(alignment["output_dir"]) / "independent_verification.json"),
        ],
        args.dry_run,
    )


if __name__ == "__main__":
    main()
