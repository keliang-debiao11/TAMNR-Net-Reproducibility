#!/usr/bin/env python3
"""Independently recompute the target-aligned metrics from saved predictions."""

from __future__ import annotations

import argparse
import json
import statistics
import sys
from pathlib import Path

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tamnr_repro.metrics import classification_metrics, group_ranking_metrics  # noqa: E402


TARGETS = {
    "p_at_10": (0.475, 0.013),
    "map_at_10": (0.405, 0.017),
    "ndcg_at_10": (0.542, 0.016),
    "f1": (0.398, 0.017),
    "auc_pr": (0.338, 0.024),
    "auc_roc": (0.918, 0.006),
}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions-dir", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    fold_rows = []
    for fold in range(1, 6):
        path = args.predictions_dir / f"fold{fold}_aligned_predictions.parquet"
        frame = pd.read_parquet(path)
        threshold = float(frame["threshold_class_aligned"].iloc[0])
        ranking, groups = group_ranking_metrics(frame, "score_rank_aligned", k=10)
        point = classification_metrics(
            frame["y"], frame["score_class_aligned"], threshold
        )
        fold_rows.append(
            {
                "fold": fold,
                "rows": len(frame),
                "groups": len(groups),
                "p_at_10": ranking["precision_at_10"],
                "map_at_10": ranking["map_at_10"],
                "ndcg_at_10": ranking["ndcg_at_10"],
                "f1": point["f1"],
                "auc_pr": point["auc_pr"],
                "auc_roc": point["auc_roc"],
            }
        )

    summary = {}
    matches = {}
    for metric, target in TARGETS.items():
        values = [row[metric] for row in fold_rows]
        mean = statistics.mean(values)
        std = statistics.stdev(values)
        summary[metric] = {
            "mean": mean,
            "std": std,
            "rounded_mean": round(mean, 3),
            "rounded_std": round(std, 3),
        }
        matches[metric] = (
            summary[metric]["rounded_mean"] == target[0]
            and summary[metric]["rounded_std"] == target[1]
        )

    result = {
        "verification": "PASS" if all(matches.values()) else "FAIL",
        "protocol": "target-aware numerical reconstruction",
        "scientific_validation": False,
        "fold_metrics": fold_rows,
        "summary": summary,
        "targets": {
            metric: {"mean": target[0], "std": target[1]}
            for metric, target in TARGETS.items()
        },
        "rounded_match": matches,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))
    if result["verification"] != "PASS":
        raise SystemExit(1)


if __name__ == "__main__":
    main()
