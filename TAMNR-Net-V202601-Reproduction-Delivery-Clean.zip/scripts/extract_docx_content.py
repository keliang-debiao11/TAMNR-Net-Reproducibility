#!/usr/bin/env python3
"""Extract paragraphs and tables from a DOCX in document order."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from docx import Document
from docx.document import Document as DocumentType
from docx.table import Table
from docx.text.paragraph import Paragraph
from docx.oxml.table import CT_Tbl
from docx.oxml.text.paragraph import CT_P


WORD_TEXT_TAG = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}t"
MATH_TEXT_TAG = "{http://schemas.openxmlformats.org/officeDocument/2006/math}t"


def iter_blocks(document: DocumentType):
    for child in document.element.body.iterchildren():
        if isinstance(child, CT_P):
            yield Paragraph(child, document)
        elif isinstance(child, CT_Tbl):
            yield Table(child, document)


def normalize(text: str) -> str:
    return " ".join(text.replace("\xa0", " ").split())


def element_text(element) -> str:
    parts = [
        node.text or ""
        for node in element.iter()
        if node.tag in {WORD_TEXT_TAG, MATH_TEXT_TAG}
    ]
    return normalize("".join(parts))


def extract(input_path: Path) -> list[dict]:
    document = Document(input_path)
    blocks: list[dict] = []
    paragraph_index = 0
    table_index = 0
    for block in iter_blocks(document):
        if isinstance(block, Paragraph):
            text = element_text(block._p)
            if not text:
                continue
            paragraph_index += 1
            blocks.append(
                {
                    "type": "paragraph",
                    "index": paragraph_index,
                    "style": block.style.name if block.style else None,
                    "text": text,
                }
            )
            continue

        table_index += 1
        rows = []
        for row in block.rows:
            rows.append([element_text(cell._tc) for cell in row.cells])
        blocks.append(
            {
                "type": "table",
                "index": table_index,
                "rows": rows,
            }
        )
    return blocks


def render_text(blocks: list[dict]) -> str:
    lines: list[str] = []
    for block in blocks:
        if block["type"] == "paragraph":
            lines.append(
                f"[P{block['index']:04d} | {block['style']}] {block['text']}"
            )
        else:
            lines.append(f"\n[TABLE {block['index']:02d}]")
            for row_index, row in enumerate(block["rows"], start=1):
                cells = " | ".join(row)
                lines.append(f"  R{row_index:03d}: {cells}")
            lines.append(f"[/TABLE {block['index']:02d}]\n")
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--json", type=Path, required=True)
    parser.add_argument("--text", type=Path, required=True)
    args = parser.parse_args()

    blocks = extract(args.input)
    args.json.parent.mkdir(parents=True, exist_ok=True)
    args.text.parent.mkdir(parents=True, exist_ok=True)
    args.json.write_text(json.dumps(blocks, indent=2), encoding="utf-8")
    args.text.write_text(render_text(blocks), encoding="utf-8")
    paragraph_count = sum(block["type"] == "paragraph" for block in blocks)
    table_count = sum(block["type"] == "table" for block in blocks)
    print(f"Extracted {paragraph_count} paragraphs and {table_count} tables.")


if __name__ == "__main__":
    main()
