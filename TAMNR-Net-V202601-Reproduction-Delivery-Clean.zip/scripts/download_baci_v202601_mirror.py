#!/usr/bin/env python3
"""Download and verify the BACI HS92 V202601 Parquet mirror.

The CEPII archive can be inaccessible from some networks. This downloader uses
the public ``phbelov/world-trade-app`` GitHub release, downloads each asset in
parallel byte ranges, and verifies the SHA-256 digest published by GitHub.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import math
import os
import re
import shutil
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path


RELEASE_API = (
    "https://api.github.com/repos/phbelov/world-trade-app/"
    "releases/tags/data-v1"
)
RELEASE_PAGE = "https://github.com/phbelov/world-trade-app/releases/tag/data-v1"
EXPANDED_ASSETS_PAGE = (
    "https://github.com/phbelov/world-trade-app/releases/expanded_assets/data-v1"
)
FACT_PATTERN = re.compile(r"facts-baci-hs92-202601-(\d{4})\.parquet$")
DIM_PATTERN = re.compile(r"dims-baci-hs92-202601-.+\.parquet$")
USER_AGENT = "TAMNR-Net-BACI-Reproduction/1.0"


@dataclass(frozen=True)
class Asset:
    name: str
    size: int
    url: str
    sha256: str


def request_json(url: str) -> dict:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=60) as response:
        return json.load(response)


def request_text(url: str) -> str:
    request = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(request, timeout=60) as response:
        return response.read().decode("utf-8")


def remote_asset_size(url: str) -> int:
    request = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Range": "bytes=0-0",
            "Accept-Encoding": "identity",
        },
    )
    with urllib.request.urlopen(request, timeout=60) as response:
        content_range = response.headers.get("Content-Range", "")
        match = re.fullmatch(r"bytes 0-0/(\d+)", content_range)
        if getattr(response, "status", response.getcode()) != 206 or not match:
            raise RuntimeError(
                f"could not determine asset size for {url}: {content_range!r}"
            )
        response.read(1)
        return int(match.group(1))


def release_from_static_page(first_year: int, last_year: int) -> dict:
    """Read public asset metadata without consuming the GitHub API quota."""
    html = request_text(EXPANDED_ASSETS_PAGE)
    asset_pattern = re.compile(
        r'href="(?P<href>/phbelov/world-trade-app/releases/download/data-v1/'
        r'(?P<name>[^"/]+))".*?'
        r'<span[^>]*class="Truncate-text">sha256:'
        r'(?P<digest>[0-9a-f]{64})</span>',
        re.DOTALL,
    )
    assets = []
    for match in asset_pattern.finditer(html):
        name = match.group("name")
        fact_match = FACT_PATTERN.fullmatch(name)
        include = bool(DIM_PATTERN.fullmatch(name))
        if fact_match:
            include = first_year <= int(fact_match.group(1)) <= last_year
        if not include:
            continue
        url = "https://github.com" + match.group("href")
        assets.append(
            {
                "name": name,
                "size": remote_asset_size(url),
                "browser_download_url": url,
                "digest": "sha256:" + match.group("digest"),
            }
        )
    if not assets:
        raise RuntimeError("no BACI V202601 assets found on the static release page")
    return {
        "html_url": RELEASE_PAGE,
        "tag_name": "data-v1",
        "assets": assets,
    }


def request_release(first_year: int, last_year: int) -> dict:
    try:
        return request_json(RELEASE_API)
    except urllib.error.HTTPError as error:
        if error.code not in {403, 429}:
            raise
        print(
            f"GitHub API returned HTTP {error.code}; using static release metadata.",
            flush=True,
        )
        return release_from_static_page(first_year, last_year)


def parse_assets(release: dict, first_year: int, last_year: int) -> list[Asset]:
    selected: list[Asset] = []
    for raw in release["assets"]:
        name = raw["name"]
        match = FACT_PATTERN.fullmatch(name)
        include = bool(DIM_PATTERN.fullmatch(name))
        if match:
            include = first_year <= int(match.group(1)) <= last_year
        if not include:
            continue

        digest = raw.get("digest") or ""
        if not digest.startswith("sha256:"):
            raise RuntimeError(f"GitHub did not publish a SHA-256 for {name}")
        selected.append(
            Asset(
                name=name,
                size=int(raw["size"]),
                url=raw["browser_download_url"],
                sha256=digest.removeprefix("sha256:"),
            )
        )

    selected.sort(key=lambda asset: (not asset.name.startswith("dims-"), asset.name))
    expected_years = set(range(first_year, last_year + 1))
    found_years = {
        int(match.group(1))
        for asset in selected
        if (match := FACT_PATTERN.fullmatch(asset.name))
    }
    if found_years != expected_years:
        missing = sorted(expected_years - found_years)
        raise RuntimeError(f"Release is missing requested fact years: {missing}")
    return selected


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def verified(path: Path, asset: Asset) -> bool:
    return (
        path.is_file()
        and path.stat().st_size == asset.size
        and file_sha256(path) == asset.sha256
    )


def download_range(
    asset: Asset,
    part_path: Path,
    start: int,
    end: int,
    attempts: int,
) -> int:
    expected_size = end - start + 1
    if part_path.is_file() and part_path.stat().st_size == expected_size:
        return expected_size

    temporary = part_path.with_suffix(".tmp")
    for attempt in range(1, attempts + 1):
        try:
            request = urllib.request.Request(
                asset.url,
                headers={
                    "User-Agent": USER_AGENT,
                    "Range": f"bytes={start}-{end}",
                    "Accept-Encoding": "identity",
                },
            )
            with urllib.request.urlopen(request, timeout=180) as response:
                status = getattr(response, "status", response.getcode())
                content_range = response.headers.get("Content-Range", "")
                expected_range = f"bytes {start}-{end}/{asset.size}"
                if status != 206 or content_range != expected_range:
                    raise RuntimeError(
                        f"range rejected: HTTP {status}, Content-Range={content_range!r}"
                    )
                with temporary.open("wb") as output:
                    shutil.copyfileobj(response, output, length=1024 * 1024)
            actual_size = temporary.stat().st_size
            if actual_size != expected_size:
                raise RuntimeError(
                    f"short part: expected {expected_size}, received {actual_size}"
                )
            os.replace(temporary, part_path)
            return expected_size
        except (OSError, RuntimeError, urllib.error.URLError) as error:
            temporary.unlink(missing_ok=True)
            if attempt == attempts:
                raise RuntimeError(
                    f"failed {asset.name} bytes {start}-{end}: {error}"
                ) from error
            time.sleep(min(2**attempt, 30))
    raise AssertionError("unreachable")


def safe_remove_parts(parts_dir: Path, parts_root: Path) -> None:
    resolved = parts_dir.resolve()
    try:
        resolved.relative_to(parts_root.resolve())
    except ValueError as error:
        raise RuntimeError(f"refusing to remove unsafe path: {resolved}") from error
    shutil.rmtree(resolved)


def download_asset(asset: Asset, output_dir: Path, workers: int, attempts: int) -> None:
    destination = output_dir / asset.name
    if verified(destination, asset):
        print(f"[verified] {asset.name}", flush=True)
        return

    parts_root = output_dir / ".parts"
    parts_dir = parts_root / asset.name
    parts_dir.mkdir(parents=True, exist_ok=True)

    part_count = min(workers, max(1, math.ceil(asset.size / (1024 * 1024))))
    chunk_size = math.ceil(asset.size / part_count)
    ranges: list[tuple[int, int, Path]] = []
    for index in range(part_count):
        start = index * chunk_size
        end = min(asset.size - 1, start + chunk_size - 1)
        if start <= end:
            ranges.append((start, end, parts_dir / f"{index:03d}.part"))

    print(
        f"[download] {asset.name} ({asset.size / 1024**2:.1f} MiB, "
        f"{len(ranges)} ranges)",
        flush=True,
    )
    completed = 0
    last_percent = -1
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        futures = {
            executor.submit(
                download_range, asset, part_path, start, end, attempts
            ): (start, end)
            for start, end, part_path in ranges
        }
        for future in concurrent.futures.as_completed(futures):
            completed += future.result()
            percent = int(completed * 100 / asset.size)
            if percent // 10 != last_percent // 10 or percent == 100:
                print(f"  {asset.name}: {percent}%", flush=True)
                last_percent = percent

    assembling = destination.with_suffix(destination.suffix + ".assembling")
    with assembling.open("wb") as output:
        for _, _, part_path in ranges:
            with part_path.open("rb") as part:
                shutil.copyfileobj(part, output, length=4 * 1024 * 1024)

    if assembling.stat().st_size != asset.size:
        raise RuntimeError(f"assembled size mismatch for {asset.name}")
    actual_digest = file_sha256(assembling)
    if actual_digest != asset.sha256:
        raise RuntimeError(
            f"SHA-256 mismatch for {asset.name}: {actual_digest} != {asset.sha256}"
        )
    os.replace(assembling, destination)
    safe_remove_parts(parts_dir, parts_root)
    print(f"[complete] {asset.name} sha256={actual_digest}", flush=True)


def write_manifest(output_dir: Path, release: dict, assets: list[Asset]) -> None:
    manifest = {
        "source_release": release["html_url"],
        "release_tag": release["tag_name"],
        "downloaded_at_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "assets": [
            {"name": asset.name, "size": asset.size, "sha256": asset.sha256}
            for asset in assets
        ],
    }
    path = output_dir / "download_manifest.json"
    temporary = path.with_suffix(".json.tmp")
    temporary.write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    os.replace(temporary, path)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(r"D:\Datasets\BACI_HS92_V202601_parquet"),
    )
    parser.add_argument("--first-year", type=int, default=1995)
    parser.add_argument("--last-year", type=int, default=2024)
    parser.add_argument("--workers", type=int, default=32)
    parser.add_argument("--attempts", type=int, default=5)
    args = parser.parse_args()

    if args.first_year > args.last_year:
        parser.error("--first-year must not exceed --last-year")
    if args.workers < 1:
        parser.error("--workers must be positive")

    args.output.mkdir(parents=True, exist_ok=True)
    release = request_release(args.first_year, args.last_year)
    assets = parse_assets(release, args.first_year, args.last_year)
    total = sum(asset.size for asset in assets)
    print(
        f"Release {release['tag_name']}: {len(assets)} assets, "
        f"{total / 1024**3:.2f} GiB -> {args.output}",
        flush=True,
    )
    for asset in assets:
        download_asset(asset, args.output, args.workers, args.attempts)
    write_manifest(args.output, release, assets)
    print("All requested BACI V202601 assets are downloaded and verified.", flush=True)


if __name__ == "__main__":
    main()
