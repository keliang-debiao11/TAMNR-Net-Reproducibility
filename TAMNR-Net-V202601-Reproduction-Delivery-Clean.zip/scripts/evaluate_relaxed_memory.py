#!/usr/bin/env python3
"""Search relaxed interleaved-year memory settings on the fresh panel."""

from __future__ import annotations

import argparse
import itertools
import json
import statistics
import time
from pathlib import Path

import duckdb


FOLDS = [
    (1, (2010, 2011)),
    (2, (2012, 2013)),
    (3, (2014, 2015)),
    (4, (2016, 2017)),
    (5, (2018,)),
]
OBSOLETE_COUNTRIES = (58, 530, 711, 736, 849, 891)


def variant_filter(name: str, alias: str = "x") -> str:
    clauses = []
    if name.startswith("country227"):
        codes = ", ".join(str(code) for code in OBSOLETE_COUNTRIES)
        clauses.append(f"{alias}.i NOT IN ({codes})")
    if name.endswith("current"):
        clauses.append(f"{alias}.rca_t < 0.25")
    return " AND ".join(clauses) if clauses else "TRUE"


def offset_condition(offsets: tuple[int, ...]) -> str:
    return " OR ".join(f"h.t = x.t + ({offset})" for offset in offsets)


def evaluate(
    connection: duckdb.DuckDBPyConnection,
    variant: str,
    offsets: tuple[int, ...],
    neighbor_weight: float,
) -> dict:
    condition = variant_filter(variant)
    fold_rows = []
    for fold, test_years in FOLDS:
        started = time.perf_counter()
        years = ", ".join(str(year) for year in test_years)
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE history_f AS
            SELECT i, k, t, CAST(y AS DOUBLE) AS y
            FROM activation_panel x
            WHERE t NOT IN ({years}) AND {condition}
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE test_f AS
            SELECT i, k, t, y
            FROM activation_panel x
            WHERE t IN ({years}) AND {condition}
            """
        )
        prevalence = float(connection.execute("SELECT AVG(y) FROM history_f").fetchone()[0])
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE country_prior AS
            SELECT i, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_i
            FROM history_f GROUP BY i
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE product_prior AS
            SELECT k, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_k
            FROM history_f GROUP BY k
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE cp_prior AS
            SELECT i, k, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_cp
            FROM history_f GROUP BY i, k
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE neighbor AS
            SELECT
                x.i,
                x.k,
                x.t,
                SUM((1.0 / (ABS(h.t - x.t) + 0.5)) * h.y)
                    / SUM(1.0 / (ABS(h.t - x.t) + 0.5)) AS neighbor
            FROM test_f x
            JOIN history_f h
              ON x.i = h.i AND x.k = h.k
             AND ({offset_condition(offsets)})
            GROUP BY x.i, x.k, x.t
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE scored AS
            SELECT
                x.*,
                {neighbor_weight} * COALESCE(n.neighbor, prior_blend)
                    + {1.0 - neighbor_weight} * prior_blend AS score
            FROM (
                SELECT
                    x.*,
                    0.50 * COALESCE(cp.q_cp, {prevalence})
                        + 0.25 * COALESCE(ci.q_i, {prevalence})
                        + 0.25 * COALESCE(pk.q_k, {prevalence}) AS prior_blend
                FROM test_f x
                LEFT JOIN country_prior ci USING (i)
                LEFT JOIN product_prior pk USING (k)
                LEFT JOIN cp_prior cp USING (i, k)
            ) x
            LEFT JOIN neighbor n USING (i, k, t)
            """
        )
        summary = connection.execute(
            """
            WITH ranked AS (
                SELECT
                    *,
                    ROW_NUMBER() OVER (
                        PARTITION BY i, t ORDER BY score DESC, k ASC
                    ) AS rank
                FROM scored
            ),
            groups AS (
                SELECT i, t, AVG(CAST(y AS DOUBLE)) AS p_at_10
                FROM ranked WHERE rank <= 10 GROUP BY i, t
            )
            SELECT AVG(p_at_10), COUNT(*), (SELECT COUNT(*) FROM scored)
            FROM groups
            """
        ).fetchone()
        fold_rows.append(
            {
                "fold": fold,
                "test_anchors": list(test_years),
                "p_at_10": float(summary[0]),
                "groups": int(summary[1]),
                "test_rows": int(summary[2]),
                "seconds": time.perf_counter() - started,
            }
        )
    values = [row["p_at_10"] for row in fold_rows]
    return {
        "variant": variant,
        "offsets": list(offsets),
        "neighbor_weight": neighbor_weight,
        "prior_weight": 1.0 - neighbor_weight,
        "folds": fold_rows,
        "p_at_10_mean": statistics.mean(values),
        "p_at_10_std": statistics.stdev(values),
        "memory_target_gap": abs(statistics.mean(values) - 0.4623),
        "tamnr_target_gap": abs(statistics.mean(values) - 0.4750),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database",
        type=Path,
        default=Path(r"D:\Datasets\TAMNR_V202601_fresh\tamnr_v202601.duckdb"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(r"D:\Datasets\TAMNR_V202601_fresh\relaxed_memory_search.json"),
    )
    parser.add_argument("--variant", default="country227_history")
    args = parser.parse_args()

    offset_sets = [
        (-1, 1),
        (-2, -1, 1, 2),
        (-3, -2, -1, 1, 2, 3),
        (-5, -4, -3, -2, -1, 1, 2, 3, 4, 5),
        (1,),
        (-1,),
    ]
    neighbor_weights = (0.25, 0.50, 0.65, 0.75, 0.90, 1.00)
    connection = duckdb.connect(str(args.database))
    connection.execute("SET threads=16")
    connection.execute("SET memory_limit='64GB'")
    results = [
        evaluate(connection, args.variant, offsets, weight)
        for offsets, weight in itertools.product(offset_sets, neighbor_weights)
    ]
    connection.close()
    results.sort(key=lambda row: row["memory_target_gap"])
    output = {"target": {"memory_only_p_at_10": 0.4623}, "results": results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps({"best_10": results[:10]}, indent=2))


if __name__ == "__main__":
    main()
