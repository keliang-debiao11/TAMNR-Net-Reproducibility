from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--summary", type=Path, required=True)
    parser.add_argument("--model", default="tamnr_bce")
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    expected = json.loads(
        (ROOT / "reference/manuscript_expected.json").read_text(encoding="utf-8")
    )["main_results"]
    with args.summary.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    candidates = [row for row in rows if row.get("model") == args.model]
    if not candidates:
        raise ValueError(f"Model {args.model!r} not found in {args.summary}")
    row = candidates[0]
    mapping = {
        "p_at_10": "p_at_10",
        "map_at_10": "map_at_10",
        "ndcg_at_10": "ndcg_at_10",
        "f1": "f1",
        "auc_pr": "auc_pr",
        "auc_roc": "auc_roc",
    }
    checks = []
    for expected_name, output_name in mapping.items():
        spec = expected[expected_name]
        mean = float(row[f"{output_name}_mean"])
        std = float(row[f"{output_name}_std"])
        decimals = int(spec["decimals"])
        checks.append(
            {
                "metric": expected_name,
                "expected_mean": spec["mean"],
                "computed_mean": mean,
                "expected_std": spec["std"],
                "computed_std": std,
                "match": round(mean, decimals) == spec["mean"]
                and round(std, decimals) == spec["std"],
            }
        )
    result = {
        "status": "PASS" if all(c["match"] for c in checks) else "FAIL",
        "model": args.model,
        "checks": checks,
    }
    payload = json.dumps(result, indent=2, ensure_ascii=False)
    print(payload)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(payload + "\n", encoding="utf-8")
    return 0 if result["status"] == "PASS" else 2


if __name__ == "__main__":
    raise SystemExit(main())
