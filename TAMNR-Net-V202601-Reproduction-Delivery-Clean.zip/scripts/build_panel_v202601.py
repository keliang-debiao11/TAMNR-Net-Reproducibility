#!/usr/bin/env python3
"""Build the fresh BACI HS92 V202601 activation panel with DuckDB."""

from __future__ import annotations

import argparse
import hashlib
import json
import time
from pathlib import Path

import duckdb


def sql_path(path: Path) -> str:
    return path.resolve().as_posix().replace("'", "''")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(4 * 1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def scalar_dict(connection: duckdb.DuckDBPyConnection, query: str) -> dict:
    cursor = connection.execute(query)
    row = cursor.fetchone()
    return dict(zip([column[0] for column in cursor.description], row, strict=True))


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--raw-dir",
        type=Path,
        default=Path(r"D:\Datasets\BACI_HS92_V202601_parquet"),
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(r"D:\Datasets\TAMNR_V202601_fresh"),
    )
    parser.add_argument("--start-year", type=int, default=1995)
    parser.add_argument("--end-year", type=int, default=2023)
    parser.add_argument("--anchor-min", type=int, default=1996)
    parser.add_argument("--anchor-max", type=int, default=2018)
    parser.add_argument("--memory-limit", default="64GB")
    parser.add_argument("--threads", type=int, default=16)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    temp_dir = args.output_dir / "duckdb_tmp"
    temp_dir.mkdir(parents=True, exist_ok=True)
    database = args.output_dir / "tamnr_v202601.duckdb"
    panel_path = args.output_dir / "activation_panel_v202601.parquet"
    audit_path = args.output_dir / "panel_audit.json"
    raw_glob = args.raw_dir / "facts-baci-hs92-202601-*.parquet"
    manifest_path = args.raw_dir / "download_manifest.json"

    started = time.perf_counter()
    connection = duckdb.connect(str(database))
    connection.execute(f"SET threads={int(args.threads)}")
    connection.execute(f"SET memory_limit='{args.memory_limit}'")
    connection.execute(f"SET temp_directory='{sql_path(temp_dir)}'")
    connection.execute("SET preserve_insertion_order=false")

    connection.execute(
        f"""
        CREATE OR REPLACE TABLE exports AS
        SELECT
            CAST(year AS SMALLINT) AS t,
            CAST(exporter AS INTEGER) AS i,
            CAST(hs6 AS VARCHAR) AS k,
            SUM(CAST(value_usd AS DOUBLE)) AS v
        FROM read_parquet('{sql_path(raw_glob)}')
        WHERE year BETWEEN {args.start_year} AND {args.end_year}
          AND value_usd > 0
        GROUP BY year, exporter, hs6
        """
    )
    connection.execute(
        f"""
        CREATE OR REPLACE TABLE panel_zero_filled AS
        WITH
        years AS (
            SELECT CAST(range AS SMALLINT) AS t
            FROM range({args.start_year}, {args.end_year + 1})
        ),
        countries AS (SELECT DISTINCT i FROM exports),
        products AS (SELECT DISTINCT k FROM exports)
        SELECT years.t, countries.i, products.k, COALESCE(exports.v, 0.0) AS v
        FROM years
        CROSS JOIN countries
        CROSS JOIN products
        LEFT JOIN exports USING (t, i, k)
        """
    )
    connection.execute(
        """
        CREATE OR REPLACE TABLE panel_rca AS
        WITH totals AS (
            SELECT
                t, i, k, v,
                SUM(v) OVER (PARTITION BY t, i) AS country_total,
                SUM(v) OVER (PARTITION BY t, k) AS product_total,
                SUM(v) OVER (PARTITION BY t) AS world_total
            FROM panel_zero_filled
        )
        SELECT
            *,
            CASE
                WHEN country_total > 0 AND product_total > 0 AND world_total > 0
                THEN (v / country_total) / (product_total / world_total)
                ELSE 0.0
            END AS rca_t
        FROM totals
        """
    )
    connection.execute(
        """
        CREATE OR REPLACE TABLE panel_features_all AS
        WITH lagged AS (
            SELECT
                *,
                COALESCE(LAG(rca_t, 1) OVER cp, 0.0) AS rca_lag1,
                COALESCE(LAG(rca_t, 2) OVER cp, 0.0) AS rca_lag2,
                COALESCE(LAG(rca_t, 5) OVER cp, 0.0) AS rca_lag5,
                COALESCE(LAG(v, 1) OVER cp, 0.0) AS export_lag1,
                COALESCE(LAG(v, 3) OVER cp, 0.0) AS export_lag3,
                COALESCE(
                    MAX(rca_t) OVER (
                        PARTITION BY i, k ORDER BY t
                        ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
                    ),
                    0.0
                ) AS max_rca_history,
                LEAD(rca_t, 5) OVER cp AS target_rca,
                SUM(CASE WHEN rca_t >= 1.0 THEN 1 ELSE 0 END)
                    OVER (PARTITION BY t, i) AS country_diversity,
                SUM(CASE WHEN rca_t >= 1.0 THEN 1 ELSE 0 END)
                    OVER (PARTITION BY t, k) AS product_ubiquity
            FROM panel_rca
            WINDOW cp AS (PARTITION BY i, k ORDER BY t)
        ),
        product_year AS (
            SELECT DISTINCT t, k, product_total
            FROM panel_rca
        ),
        product_context AS (
            SELECT
                t, k, product_total,
                LN(1.0 + product_total)
                - LN(
                    1.0 + COALESCE(
                        LAG(product_total, 3) OVER (PARTITION BY k ORDER BY t),
                        0.0
                    )
                ) AS product_world_growth_3
            FROM product_year
        )
        SELECT
            lagged.t,
            lagged.i,
            lagged.k,
            lagged.v,
            lagged.rca_t,
            lagged.rca_lag1,
            lagged.rca_lag2,
            lagged.rca_lag5,
            LN(1.0 + lagged.v) AS log_export_t,
            LN(1.0 + lagged.v) - LN(1.0 + lagged.export_lag1) AS export_growth_1,
            LN(1.0 + lagged.v) - LN(1.0 + lagged.export_lag3) AS export_growth_3,
            lagged.max_rca_history,
            lagged.country_diversity,
            lagged.product_ubiquity,
            product_context.product_world_growth_3,
            LN(1.0 + lagged.country_total) AS country_total_log,
            LN(1.0 + lagged.product_total) AS product_total_log,
            lagged.target_rca,
            CAST(lagged.t + 5 AS SMALLINT) AS target_year,
            CAST(lagged.target_rca >= 1.0 AS UTINYINT) AS y
        FROM lagged
        JOIN product_context USING (t, k)
        """
    )
    connection.execute(
        f"""
        CREATE OR REPLACE TABLE activation_panel AS
        SELECT *
        FROM panel_features_all
        WHERE t BETWEEN {args.anchor_min} AND {args.anchor_max}
          AND max_rca_history < 0.25
          AND target_rca IS NOT NULL
        """
    )
    connection.execute(
        f"""
        COPY (
            SELECT * FROM activation_panel ORDER BY t, i, k
        ) TO '{sql_path(panel_path)}'
        (FORMAT PARQUET, COMPRESSION ZSTD, ROW_GROUP_SIZE 250000, OVERWRITE_OR_IGNORE true)
        """
    )

    panel_stats = scalar_dict(
        connection,
        """
        SELECT
            COUNT(*) AS rows,
            COUNT(DISTINCT i) AS countries,
            COUNT(DISTINCT k) AS products,
            MIN(t) AS anchor_min,
            MAX(t) AS anchor_max,
            AVG(CAST(y AS DOUBLE)) AS positive_rate
        FROM activation_panel
        """,
    )
    raw_stats = scalar_dict(
        connection,
        """
        SELECT
            COUNT(*) AS aggregated_export_rows,
            COUNT(DISTINCT i) AS countries,
            COUNT(DISTINCT k) AS products,
            MIN(t) AS year_min,
            MAX(t) AS year_max
        FROM exports
        """,
    )
    test_group_stats = scalar_dict(
        connection,
        """
        WITH counts AS (
            SELECT i, t, COUNT(*) AS candidates
            FROM activation_panel
            WHERE t BETWEEN 2010 AND 2018
            GROUP BY i, t
        )
        SELECT
            COUNT(*) AS country_year_groups,
            MIN(candidates) AS min_candidates,
            AVG(candidates) AS mean_candidates,
            MAX(candidates) AS max_candidates
        FROM counts
        """,
    )
    by_anchor = [
        dict(zip([column[0] for column in cursor.description], row, strict=True))
        for cursor in [
            connection.execute(
                """
                SELECT
                    t,
                    COUNT(*) AS rows,
                    COUNT(DISTINCT i) AS countries,
                    COUNT(DISTINCT k) AS products,
                    AVG(CAST(y AS DOUBLE)) AS positive_rate
                FROM activation_panel
                GROUP BY t
                ORDER BY t
                """
            )
        ]
        for row in cursor.fetchall()
    ]
    audit = {
        "source": "BACI HS92 V202601 GitHub release mirror",
        "raw_directory": str(args.raw_dir.resolve()),
        "raw_manifest_sha256": (
            file_sha256(manifest_path) if manifest_path.is_file() else None
        ),
        "years": [args.start_year, args.end_year],
        "anchors": [args.anchor_min, args.anchor_max],
        "candidate_rule": "max_rca_history < 0.25",
        "label_rule": "RCA(t+5) >= 1.0",
        "raw_aggregated": raw_stats,
        "activation_panel": panel_stats,
        "test_country_year_groups": test_group_stats,
        "by_anchor": by_anchor,
        "panel_path": str(panel_path.resolve()),
        "panel_sha256": file_sha256(panel_path),
        "elapsed_seconds": time.perf_counter() - started,
    }
    audit_path.write_text(json.dumps(audit, indent=2), encoding="utf-8")
    connection.close()
    print(json.dumps(audit, indent=2))


if __name__ == "__main__":
    main()
