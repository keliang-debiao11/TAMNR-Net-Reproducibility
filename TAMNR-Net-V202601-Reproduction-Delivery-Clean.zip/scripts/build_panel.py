from __future__ import annotations

import argparse
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tamnr_repro.data import aggregate_zip, build_features  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--zip", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--start-year", type=int, default=1995)
    parser.add_argument("--end-year", type=int, default=2023)
    parser.add_argument("--horizon", type=int, default=5)
    args = parser.parse_args()
    exports = aggregate_zip(args.zip, range(args.start_year, args.end_year + 1))
    panel = build_features(exports, horizon=args.horizon)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    if args.output.suffix.lower() in {".parquet", ".pq"}:
        panel.to_parquet(args.output, index=False)
    else:
        panel.to_csv(args.output, index=False, compression="infer")
    print(
        {
            "rows": len(panel),
            "countries": panel["i"].nunique(),
            "products": panel["k"].nunique(),
            "anchors": [int(panel["t"].min()), int(panel["t"].max())],
            "positive_rate": float(panel["y"].mean()),
        }
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
