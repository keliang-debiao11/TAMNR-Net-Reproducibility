from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys

import pandas as pd


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from tamnr_repro.calibration import BetaCalibrator  # noqa: E402
from tamnr_repro.metrics import (  # noqa: E402
    classification_metrics,
    expected_calibration_error,
    fold_mean_std,
    group_ranking_metrics,
)


def read_frame(path: Path) -> pd.DataFrame:
    if path.suffix.lower() in {".parquet", ".pq"}:
        return pd.read_parquet(path)
    return pd.read_csv(path)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--predictions", type=Path, required=True)
    parser.add_argument("--calibration", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--top-k", type=int, default=10)
    args = parser.parse_args()

    frame = read_frame(args.predictions)
    required = {"fold", "i", "t", "y"}
    missing = required.difference(frame.columns)
    if missing:
        raise ValueError(f"Missing prediction columns: {sorted(missing)}")
    score_cols = [c for c in frame.columns if c.startswith("score_")]
    if not score_cols:
        raise ValueError("No score_* columns were found")
    calibration = read_frame(args.calibration) if args.calibration else None

    fold_rows = []
    group_frames = []
    probability_rows = []
    beta_parameters = []
    for score_col in score_cols:
        model = score_col.removeprefix("score_")
        for fold, fold_frame in frame.groupby("fold", sort=True):
            ranking, groups = group_ranking_metrics(
                fold_frame, score_col=score_col, k=args.top_k
            )
            groups = groups.assign(fold=int(fold), model=model)
            group_frames.append(groups)
            threshold = 0.5
            if calibration is not None and score_col in calibration.columns:
                cal = calibration[calibration["fold"].eq(fold)]
                threshold_path = args.output_dir / f"threshold_{model}_fold{int(fold)}.json"
                from tamnr_repro.metrics import best_f1_threshold

                threshold, cal_f1 = best_f1_threshold(cal["y"], cal[score_col])
                threshold_path.parent.mkdir(parents=True, exist_ok=True)
                threshold_path.write_text(
                    json.dumps({"threshold": threshold, "calibration_f1": cal_f1}, indent=2),
                    encoding="utf-8",
                )
            else:
                threshold_col = f"threshold_{model}"
                if threshold_col in fold_frame.columns:
                    threshold = float(fold_frame[threshold_col].iloc[0])
            point = classification_metrics(fold_frame["y"], fold_frame[score_col], threshold)
            fold_rows.append(
                {
                    "model": model,
                    "fold": int(fold),
                    "p_at_10": ranking["precision_at_10"],
                    "map_at_10": ranking["map_at_10"],
                    "ndcg_at_10": ranking["ndcg_at_10"],
                    "hit_at_10": ranking["hit_at_10"],
                    "recall_at_10": ranking["recall_at_10"],
                    **point,
                }
            )
            probability_rows.append(
                {
                    "model": model,
                    "fold": int(fold),
                    "series": "raw",
                    "brier": point["brier"],
                    "nll": point["nll"],
                    "ece": expected_calibration_error(
                        fold_frame["y"], fold_frame[score_col]
                    ),
                }
            )
            if calibration is not None and score_col in calibration.columns:
                calibrator = BetaCalibrator().fit(cal[score_col], cal["y"])
                beta_score = calibrator.predict_proba(fold_frame[score_col])
                beta_point = classification_metrics(
                    fold_frame["y"], beta_score, threshold=0.5
                )
                probability_rows.append(
                    {
                        "model": model,
                        "fold": int(fold),
                        "series": "beta",
                        "brier": beta_point["brier"],
                        "nll": beta_point["nll"],
                        "ece": expected_calibration_error(
                            fold_frame["y"], beta_score
                        ),
                    }
                )
                beta_parameters.append(
                    {
                        "model": model,
                        "fold": int(fold),
                        "coef": calibrator.model.coef_[0].tolist(),
                        "intercept": float(calibrator.model.intercept_[0]),
                    }
                )

    fold_df = pd.DataFrame(fold_rows)
    summaries = []
    for model, model_folds in fold_df.groupby("model", sort=False):
        row = {"model": model, "folds": int(len(model_folds))}
        for metric in ["p_at_10", "map_at_10", "ndcg_at_10", "f1", "auc_pr", "auc_roc", "brier", "nll"]:
            mean, std = fold_mean_std(model_folds, metric)
            row[f"{metric}_mean"] = mean
            row[f"{metric}_std"] = std
        summaries.append(row)
    summary_df = pd.DataFrame(summaries)
    probability_df = pd.DataFrame(probability_rows)
    probability_summaries = []
    for (model, series), values in probability_df.groupby(
        ["model", "series"], sort=False
    ):
        row = {"model": model, "series": series, "folds": int(len(values))}
        for metric in ["brier", "nll", "ece"]:
            mean, std = fold_mean_std(values, metric)
            row[f"{metric}_mean"] = mean
            row[f"{metric}_std"] = std
        probability_summaries.append(row)
    probability_summary_df = pd.DataFrame(probability_summaries)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    fold_df.to_csv(args.output_dir / "fold_metrics.csv", index=False)
    summary_df.to_csv(args.output_dir / "summary_metrics.csv", index=False)
    probability_df.to_csv(args.output_dir / "probability_fold_metrics.csv", index=False)
    probability_summary_df.to_csv(
        args.output_dir / "probability_summary_metrics.csv", index=False
    )
    (args.output_dir / "beta_calibration_parameters.json").write_text(
        json.dumps(beta_parameters, indent=2), encoding="utf-8"
    )
    if group_frames:
        pd.concat(group_frames, ignore_index=True).to_parquet(
            args.output_dir / "country_year_group_metrics.parquet", index=False
        )
    print(summary_df.to_string(index=False))
    print(probability_summary_df.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
