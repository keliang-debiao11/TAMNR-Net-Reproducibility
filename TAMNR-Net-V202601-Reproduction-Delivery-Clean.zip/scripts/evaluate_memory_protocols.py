#!/usr/bin/env python3
"""Evaluate strict fold-fitted temporal memory directly in DuckDB."""

from __future__ import annotations

import argparse
import json
import math
import statistics
import time
from pathlib import Path

import duckdb


FOLDS = [
    (1, 1996, 2002, (2010, 2011)),
    (2, 1996, 2004, (2012, 2013)),
    (3, 1996, 2006, (2014, 2015)),
    (4, 1996, 2008, (2016, 2017)),
    (5, 1996, 2010, (2018,)),
]
OBSOLETE_COUNTRIES = (58, 530, 711, 736, 849, 891)


def variant_filter(name: str, alias: str = "x") -> str:
    clauses = []
    if name in {"country227_history", "country227_current"}:
        codes = ", ".join(str(code) for code in OBSOLETE_COUNTRIES)
        clauses.append(f"{alias}.i NOT IN ({codes})")
    if name in {"all233_current", "country227_current"}:
        clauses.append(f"{alias}.rca_t < 0.25")
    return " AND ".join(clauses) if clauses else "TRUE"


def evaluate_variant(connection: duckdb.DuckDBPyConnection, variant: str) -> dict:
    condition = variant_filter(variant)
    folds = []
    for fold, train_start, train_end, test_years in FOLDS:
        started = time.perf_counter()
        test_values = ", ".join(str(year) for year in test_years)
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE train_f AS
            SELECT i, k, t, CAST(y AS DOUBLE) AS y
            FROM activation_panel x
            WHERE t BETWEEN {train_start} AND {train_end}
              AND {condition}
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE test_f AS
            SELECT i, k, t, y
            FROM activation_panel x
            WHERE t IN ({test_values})
              AND {condition}
            """
        )
        prevalence = float(connection.execute("SELECT AVG(y) FROM train_f").fetchone()[0])
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE country_prior AS
            SELECT i, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_i
            FROM train_f GROUP BY i
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE product_prior AS
            SELECT k, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_k
            FROM train_f GROUP BY k
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE cp_prior AS
            SELECT i, k, (SUM(y) + 20.0 * {prevalence}) / (COUNT(*) + 20.0) AS q_cp
            FROM train_f GROUP BY i, k
            """
        )
        connection.execute(
            """
            CREATE OR REPLACE TEMP TABLE neighbor AS
            SELECT
                x.i,
                x.k,
                x.t,
                SUM(POWER(2.0, -(x.t - h.t) / 5.0) * h.y)
                    / (SUM(POWER(2.0, -(x.t - h.t) / 5.0)) + 1e-6) AS neighbor
            FROM test_f x
            JOIN train_f h ON x.i = h.i AND x.k = h.k
            WHERE h.t < x.t AND h.t + 5 <= x.t
            GROUP BY x.i, x.k, x.t
            """
        )
        connection.execute(
            f"""
            CREATE OR REPLACE TEMP TABLE scored AS
            SELECT
                x.*,
                0.65 * COALESCE(n.neighbor, prior_blend)
                    + 0.35 * prior_blend AS score
            FROM (
                SELECT
                    x.*,
                    0.50 * COALESCE(cp.q_cp, {prevalence})
                        + 0.25 * COALESCE(ci.q_i, {prevalence})
                        + 0.25 * COALESCE(pk.q_k, {prevalence}) AS prior_blend
                FROM test_f x
                LEFT JOIN country_prior ci USING (i)
                LEFT JOIN product_prior pk USING (k)
                LEFT JOIN cp_prior cp USING (i, k)
            ) x
            LEFT JOIN neighbor n USING (i, k, t)
            """
        )
        summary = connection.execute(
            """
            WITH ranked AS (
                SELECT
                    *,
                    ROW_NUMBER() OVER (
                        PARTITION BY i, t ORDER BY score DESC, k ASC
                    ) AS rank
                FROM scored
            ),
            groups AS (
                SELECT i, t, AVG(CAST(y AS DOUBLE)) AS p_at_10
                FROM ranked WHERE rank <= 10
                GROUP BY i, t
            )
            SELECT
                AVG(p_at_10) AS p_at_10,
                COUNT(*) AS groups,
                (SELECT COUNT(*) FROM scored) AS test_rows
            FROM groups
            """
        ).fetchone()
        folds.append(
            {
                "fold": fold,
                "train_anchors": [train_start, train_end],
                "test_anchors": list(test_years),
                "train_prevalence": prevalence,
                "p_at_10": float(summary[0]),
                "groups": int(summary[1]),
                "test_rows": int(summary[2]),
                "seconds": time.perf_counter() - started,
            }
        )
    values = [row["p_at_10"] for row in folds]
    return {
        "variant": variant,
        "protocol": "strict_fold_fitted_memory",
        "folds": folds,
        "p_at_10_mean": statistics.mean(values),
        "p_at_10_std": statistics.stdev(values),
        "manuscript_memory_only": {"mean": 0.4623, "std": 0.0121},
        "absolute_mean_gap": abs(statistics.mean(values) - 0.4623),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--database",
        type=Path,
        default=Path(r"D:\Datasets\TAMNR_V202601_fresh\tamnr_v202601.duckdb"),
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path(r"D:\Datasets\TAMNR_V202601_fresh\memory_variant_audit.json"),
    )
    parser.add_argument(
        "--variants",
        nargs="+",
        default=["all233_history", "all233_current", "country227_history", "country227_current"],
    )
    args = parser.parse_args()

    connection = duckdb.connect(str(args.database))
    connection.execute("SET threads=16")
    connection.execute("SET memory_limit='64GB'")
    results = [evaluate_variant(connection, variant) for variant in args.variants]
    connection.close()
    output = {"results": results}
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(output, indent=2), encoding="utf-8")
    print(json.dumps(output, indent=2))


if __name__ == "__main__":
    main()
