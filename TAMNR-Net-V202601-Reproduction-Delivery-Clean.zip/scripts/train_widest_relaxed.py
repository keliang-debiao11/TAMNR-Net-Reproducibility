from __future__ import annotations

import argparse
import json
from pathlib import Path
import sys
import time

import joblib
import numpy as np
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import torch


ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT / "src"), str(ROOT / "scripts")]

from tamnr_repro.memory import RelaxedInterleavedMemoryEncoder  # noqa: E402
from tamnr_repro.metrics import best_f1_threshold  # noqa: E402
from tamnr_repro.model import TAMNRNet, seed_everything  # noqa: E402
from train_paper_protocol import (  # noqa: E402
    BASE_FEATURES,
    FEATURES,
    EntityEncoder,
    add_fold_features,
    fit_bce,
    predict,
    read_panel,
    stratified_sample,
    tensor_data,
)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--panel", type=Path, required=True)
    parser.add_argument("--config", type=Path, default=ROOT / "configs/widest_relaxed.json")
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    cfg = json.loads(args.config.read_text(encoding="utf-8"))
    panel = read_panel(args.panel).reset_index(drop=True)
    panel = panel[panel["t"].between(cfg["dataset"]["anchor_min"], cfg["dataset"]["anchor_max"])]
    missing = set(BASE_FEATURES + ["i", "k", "t", "y"]).difference(panel.columns)
    if missing:
        raise ValueError(f"Processed panel is missing: {sorted(missing)}")
    panel["_row_id"] = np.arange(len(panel), dtype=np.int64)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    predictions = []
    calibration_predictions = []
    logs = []
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    for fold_row in cfg["protocol"]["folds"]:
        fold = int(fold_row["fold"])
        seed = int(fold_row["seed"])
        seed_everything(seed)
        started = time.perf_counter()
        test = panel[panel["t"].isin(fold_row["test"])].copy()
        development = panel[~panel["t"].isin(fold_row["test"])].copy()
        train_pool, calibration = train_test_split(
            development,
            test_size=cfg["protocol"]["calibration_fraction"],
            random_state=seed,
            stratify=development["y"],
        )
        model_train, validation_pool = train_test_split(
            train_pool,
            test_size=cfg["protocol"]["validation_fraction"],
            random_state=seed + 1,
            stratify=train_pool["y"],
        )
        memory_cfg = dict(cfg["memory"])
        memory_cfg["offsets"] = tuple(memory_cfg["offsets"])
        memory = RelaxedInterleavedMemoryEncoder(**memory_cfg).fit(model_train)
        train_sample = stratified_sample(
            model_train, cfg["model"]["max_train_rows"], seed
        )
        validation_sample = stratified_sample(
            validation_pool, cfg["model"]["max_validation_rows"], seed + 2
        )
        train = add_fold_features(
            train_sample,
            memory,
            cfg["dataset"]["anchor_min"],
            cfg["dataset"]["anchor_max"],
        )
        validation = add_fold_features(
            validation_sample,
            memory,
            cfg["dataset"]["anchor_min"],
            cfg["dataset"]["anchor_max"],
        )
        calibration_fe = add_fold_features(
            calibration, memory, cfg["dataset"]["anchor_min"], cfg["dataset"]["anchor_max"]
        )
        test_fe = add_fold_features(
            test, memory, cfg["dataset"]["anchor_min"], cfg["dataset"]["anchor_max"]
        )
        scaler = StandardScaler().fit(train[FEATURES].to_numpy(dtype=float))
        entities = EntityEncoder().fit(model_train)
        train_data = tensor_data(train, scaler, entities)
        validation_data = tensor_data(validation, scaler, entities)
        calibration_data = tensor_data(calibration_fe, scaler, entities, include_y=False)
        test_data = tensor_data(test_fe, scaler, entities, include_y=False)
        n_c, n_p, n_t = entities.sizes
        model = TAMNRNet(
            len(FEATURES), n_c, n_p, n_t,
            hidden_dim=cfg["model"]["hidden_dim"],
            embedding_dim=cfg["model"]["embedding_dim"],
            year_embedding_dim=cfg["model"]["year_embedding_dim"],
            dropout=cfg["model"]["dropout"],
            residual_scale=cfg["model"]["residual_scale"],
            temperature_min=cfg["model"]["memory_temperature_min"],
            temperature_max=cfg["model"]["memory_temperature_max"],
        ).to(device)
        best_loss, best_epoch = fit_bce(
            model, train_data, validation_data, cfg["model"], device
        )
        cal_score = predict(model, calibration_data, cfg["model"]["batch_size"] * 8, device)
        test_score = predict(model, test_data, cfg["model"]["batch_size"] * 8, device)
        threshold, cal_f1 = best_f1_threshold(calibration_fe["y"], cal_score)
        cal_out = calibration_fe[["i", "k", "t", "y"]].copy()
        cal_out["fold"] = fold
        cal_out["score_tamnr_bce"] = cal_score
        calibration_predictions.append(cal_out)
        out = test_fe[["i", "k", "t", "y"]].copy()
        out["fold"] = fold
        out["score_tamnr_bce"] = test_score
        out["threshold_tamnr_bce"] = threshold
        predictions.append(out)
        joblib.dump(
            {
                "state_dict": {k: v.detach().cpu() for k, v in model.state_dict().items()},
                "scaler": scaler,
                "entities": entities,
                "features": FEATURES,
                "config": cfg,
                "fold": fold,
                "protocol": "widest_relaxed_interleaved_year",
                "temporal_memory": memory,
            },
            args.output_dir / f"fold{fold}_TAMNR-Net-BCE-relaxed.joblib",
        )
        np.savez_compressed(
            args.output_dir / f"fold{fold}_sampled_row_ids.npz",
            train=train_sample["_row_id"].to_numpy(dtype=np.int64),
            validation=validation_sample["_row_id"].to_numpy(dtype=np.int64),
        )
        logs.append(
            {
                "fold": fold,
                "test_years": fold_row["test"],
                "seed": seed,
                "best_validation_loss": best_loss,
                "best_epoch": best_epoch,
                "calibration_threshold": threshold,
                "calibration_f1": cal_f1,
                "train_rows_full": len(model_train),
                "train_rows_sampled": len(train_sample),
                "validation_rows_full": len(validation_pool),
                "validation_rows_sampled": len(validation_sample),
                "calibration_rows": len(calibration),
                "test_rows": len(test),
                "parameter_count": sum(p.numel() for p in model.parameters()),
                "seconds": time.perf_counter() - started,
                "protocol": "widest_relaxed_interleaved_year",
            }
        )

    pd.concat(predictions, ignore_index=True).to_parquet(
        args.output_dir / "fold_predictions.parquet", index=False
    )
    pd.concat(calibration_predictions, ignore_index=True).to_parquet(
        args.output_dir / "calibration_predictions.parquet", index=False
    )
    (args.output_dir / "training_log.json").write_text(
        json.dumps(logs, indent=2), encoding="utf-8"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
