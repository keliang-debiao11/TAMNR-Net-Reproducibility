# Reproduction Status

Status: **manuscript internally consistent; public reproduction not exact**

The code in this package implements the current manuscript protocol and can
recompute results from BACI data or fold-level predictions. The corrected
Table 19 values now reproduce Table 8 after rounding. The existing public
artifact cannot be certified as a reproduction of the current manuscript.

## Confirmed mismatches

| Item | Current manuscript | Public artifact |
| --- | --- | --- |
| Main data revision | HS92 V202501 | HS92 V202601 |
| Validation protocol | Strict expanding-window rolling origin | Relaxed interleaved-year CV |
| Residual scale | 0.010 | 0.002 |
| Epochs | 5 | 3 |
| P@10 | 0.475 +/- 0.013 | 0.4632918455 +/- 0.0137796950 |
| F1 | 0.398 +/- 0.017 | approximately 0.387 |
| AUC-PR | 0.338 +/- 0.024 | 0.3211461710 +/- 0.0255662123 |

The five fold-level P@10 values printed in the corrected manuscript Table 19
are `0.4581, 0.4811, 0.4700, 0.4919, 0.4740`. Their mean is `0.47502` and their
sample standard deviation is approximately `0.012594`; both round to the
Table 8 result of `0.475 +/- 0.013`.

This correction does not update the public artifact's recorded predictions,
checkpoints, protocol, data revision, residual scale, or epoch count.

## Evidence required for a manuscript-exact PASS

The following final-version artifacts are required:

1. Five fold-level test prediction files for TAMNR-Net-BCE, RankNet, BPR, all
   equal-input baselines, conventional LightGBM, and product-space density.
2. Five calibration-partition prediction files and fitted beta-calibration
   parameters.
3. Five final TAMNR-Net model checkpoints trained with residual scale 0.010 and
   five epochs under the stated rolling-origin folds.
4. The exact HS92 V202501 processed panel or its immutable build manifest and
   checksums.
5. HS12/HS17 crosswalk files, transferred-history panels, and mapping coverage
   audit supporting Table 15.
6. Fold-level outputs for Tables 10-20 and the 10,000-repetition country-block
   bootstrap draws or seeds.
7. The final fold-specific entity vocabularies needed to reconcile the stated
   parameter-count range with the architecture and reported entity counts.

Until those artifacts are supplied or regenerated, `audit_reproduction.py`
correctly returns `FAIL`. Changing it to return `PASS` would hide an empirical
inconsistency rather than reproduce the paper.

## Widest relaxed protocol

`configs/widest_relaxed.json` and `scripts/train_widest_relaxed.py` provide an
explicitly relaxed interleaved-year protocol. It permits same-country-product
labels at negative and positive anchor offsets when those rows are outside the
current test fold. This can be used for a widest-protocol sensitivity run, but
it is not prospective validation and must not be reported as the manuscript's
strict rolling-origin result.
