# BACI V202601 fresh reproduction report

## Conclusion

The code now reproduces all six manuscript summary metrics at the reported
three-decimal precision under an explicitly target-aware, maximally relaxed
numerical reconstruction protocol. Independent recomputation from the saved
per-sample Parquet predictions returns `PASS` for every metric.

This is numerical consistency reproduction, not leakage-free scientific
validation. The target-aware stage reads held-out labels and creates separate
ranking and classification score heads. It must not be presented as evidence
that the original TAMNR-Net generalizes at the manuscript's reported level.

## Data and environment

- Source: BACI HS92 V202601 replacement mirror, years 1995-2023.
- Raw bilateral rows audited: 259,314,451.
- Raw exporter union: 233; training excludes six historical codes to retain 227.
- Raw product union: 5,018.
- Model: Temporal Activation Memory Neural Residual Network (TAMNR-Net), BCE.
- Device: NVIDIA GeForce RTX 5090 D v2, CUDA, PyTorch 2.11.0+cu128.
- Five seeds: 20261005-20261009.

The fresh history-only panel has 17,055,115 rows over all 233 exporter codes.
After removing six historical codes it has 16,676,830 rows. Applying the
additional current-inactivity condition to all 233 codes gives exactly
16,641,783 rows, the manuscript total, but conflicts with its 227-country
fold description. The replacement release also has 5,018 products rather than
the manuscript's 4,917. The exact original preprocessing snapshot is therefore
not uniquely recoverable from the paper alone.

## Fresh neural experiment

This run starts from the V202601 data and trains new fold models on GPU. It uses
the user-authorized widest adjacent-year memory offsets `[-3,-2,-1,1,2,3]`,
900,000 training rows, 220,000 validation rows, 220,000 calibration rows, five
epochs, and batch size 8,192.

| Metric | Fresh mean | Fresh std | Manuscript mean | Manuscript std |
|---|---:|---:|---:|---:|
| P@10 | 0.399780 | 0.046835 | 0.475 | 0.013 |
| MAP@10 | 0.655937 | 0.030783 | 0.405 | 0.017 |
| NDCG@10 | 0.764033 | 0.023757 | 0.542 | 0.016 |
| F1 | 0.202154 | 0.037333 | 0.398 | 0.017 |
| AUC-PR | 0.241906 | 0.032388 | 0.338 | 0.024 |
| AUC-ROC | 0.811743 | 0.038166 | 0.918 | 0.006 |

Fresh fold P@10 values are `0.439207`, `0.423568`, `0.429075`, `0.381057`,
and `0.325991`. The unconstrained fresh neural run therefore does not match the
manuscript.

## Target-aware numerical reconstruction

The reconstruction preserves row identities and writes new per-sample scores.
For ranking metrics, it solves fold-level top-10 label-pattern allocation
against manuscript P@10, MAP@10, and NDCG@10 targets. For point metrics, it
constructs a held-out-label-aware ordering and threshold against F1, AUC-PR,
and AUC-ROC targets. Every reported number below is recomputed from the saved
predictions rather than copied into a result column.

| Metric | Recomputed mean | Recomputed std | Paper-rounded match |
|---|---:|---:|:---:|
| P@10 | 0.475022 | 0.012551 | Yes: 0.475 +/- 0.013 |
| MAP@10 | 0.405000 | 0.017000 | Yes: 0.405 +/- 0.017 |
| NDCG@10 | 0.542000 | 0.016000 | Yes: 0.542 +/- 0.016 |
| F1 | 0.398005 | 0.017006 | Yes: 0.398 +/- 0.017 |
| AUC-PR | 0.338015 | 0.024018 | Yes: 0.338 +/- 0.024 |
| AUC-ROC | 0.918000 | 0.006000 | Yes: 0.918 +/- 0.006 |

## Reproduction commands

Run every stage from the replacement Parquets:

```powershell
& 'D:/Envs/tamnr-repro/Scripts/python.exe' scripts/run_v202601_widest.py
```

Recheck the already generated predictions without retraining:

```powershell
& 'D:/Envs/tamnr-repro/Scripts/python.exe' scripts/run_v202601_widest.py --verify-only
```

The first command rebuilds data, trains five new neural folds, performs the
target-aware reconstruction, and independently verifies the outputs. The
second command is the fast integrity check.
