"""Leakage-controlled TAMNR-Net reproduction utilities."""

from .protocol import FoldSpec, strict_folds

__all__ = ["FoldSpec", "strict_folds"]
