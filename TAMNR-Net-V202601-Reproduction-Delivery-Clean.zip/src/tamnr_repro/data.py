from __future__ import annotations

from pathlib import Path
import re
from zipfile import ZipFile

import numpy as np
import pandas as pd


def normalize_columns(frame: pd.DataFrame) -> pd.DataFrame:
    lowered = {str(c).strip().lower(): c for c in frame.columns}
    aliases = {
        "t": ["t", "year"],
        "i": ["i", "exporter", "reporter", "reporter_code"],
        "j": ["j", "importer", "partner", "partner_code"],
        "k": ["k", "product", "product_code", "cmdcode", "hs6"],
        "v": ["v", "value", "trade_value", "tradevalue"],
    }
    rename = {}
    for target, candidates in aliases.items():
        for candidate in candidates:
            if candidate in lowered:
                rename[lowered[candidate]] = target
                break
    out = frame.rename(columns=rename)
    missing = {"t", "i", "k", "v"}.difference(out.columns)
    if missing:
        raise ValueError(f"Missing BACI columns: {sorted(missing)}")
    out = out[[c for c in ["t", "i", "j", "k", "v"] if c in out.columns]].copy()
    out["t"] = pd.to_numeric(out["t"], errors="coerce")
    out["i"] = out["i"].astype(str).str.strip()
    out["k"] = out["k"].astype(str).str.extract(r"(\d+)")[0].str.zfill(6)
    out["v"] = pd.to_numeric(out["v"], errors="coerce").fillna(0.0)
    return out.dropna(subset=["t", "i", "k"]).assign(t=lambda x: x["t"].astype(int))


def aggregate_zip(zip_path: Path, years: range, chunksize: int = 500_000) -> pd.DataFrame:
    pieces = []
    selected = set(int(x) for x in years)
    with ZipFile(zip_path) as archive:
        members = [name for name in archive.namelist() if name.lower().endswith(".csv")]
        for member in members:
            match = re.search(r"(19|20)\d{2}", member)
            if match and int(match.group(0)) not in selected:
                continue
            with archive.open(member) as handle:
                for chunk in pd.read_csv(handle, chunksize=chunksize):
                    chunk = normalize_columns(chunk)
                    chunk = chunk[chunk["t"].isin(selected) & chunk["v"].gt(0)]
                    if len(chunk):
                        pieces.append(chunk.groupby(["t", "i", "k"], as_index=False)["v"].sum())
    if not pieces:
        raise ValueError("No BACI rows found for the requested years")
    return pd.concat(pieces, ignore_index=True).groupby(["t", "i", "k"], as_index=False)["v"].sum()


def complete_panel(exports: pd.DataFrame) -> pd.DataFrame:
    grid = pd.MultiIndex.from_product(
        [sorted(exports["t"].unique()), sorted(exports["i"].unique()), sorted(exports["k"].unique())],
        names=["t", "i", "k"],
    ).to_frame(index=False)
    return grid.merge(exports, on=["t", "i", "k"], how="left").fillna({"v": 0.0})


def build_features(exports: pd.DataFrame, horizon: int = 5) -> pd.DataFrame:
    out = complete_panel(exports)
    out["country_total"] = out.groupby(["t", "i"], observed=True)["v"].transform("sum")
    out["product_total"] = out.groupby(["t", "k"], observed=True)["v"].transform("sum")
    world = out.groupby("t", observed=True)["v"].transform("sum")
    country_share = np.divide(
        out["v"], out["country_total"], out=np.zeros(len(out)), where=out["country_total"].to_numpy() > 0
    )
    product_share = np.divide(
        out["product_total"], world, out=np.zeros(len(out)), where=world.to_numpy() > 0
    )
    out["rca_t"] = np.divide(
        country_share, product_share, out=np.zeros(len(out)), where=product_share.to_numpy() > 0
    )
    out = out.sort_values(["i", "k", "t"]).reset_index(drop=True)
    grouped = out.groupby(["i", "k"], sort=False, observed=True)
    for lag in [1, 2, 5]:
        out[f"rca_lag{lag}"] = grouped["rca_t"].shift(lag).fillna(0.0)
    export_lag1 = grouped["v"].shift(1).fillna(0.0)
    export_lag3 = grouped["v"].shift(3).fillna(0.0)
    out["log_export_t"] = np.log1p(out["v"])
    out["export_growth_1"] = np.log1p(out["v"]) - np.log1p(export_lag1)
    out["export_growth_3"] = np.log1p(out["v"]) - np.log1p(export_lag3)
    out["max_rca_history"] = grouped["rca_t"].transform(lambda s: s.shift(1).cummax()).fillna(0.0)
    competitive = out["rca_t"].ge(1.0).astype(int)
    out["country_diversity"] = competitive.groupby([out["t"], out["i"]]).transform("sum")
    out["product_ubiquity"] = competitive.groupby([out["t"], out["k"]]).transform("sum")
    product_year = out[["t", "k", "product_total"]].drop_duplicates().sort_values(["k", "t"])
    product_year["product_world_growth_3"] = np.log1p(product_year["product_total"]) - np.log1p(
        product_year.groupby("k", observed=True)["product_total"].shift(3).fillna(0.0)
    )
    out = out.merge(product_year[["t", "k", "product_world_growth_3"]], on=["t", "k"], how="left")
    out["country_total_log"] = np.log1p(out["country_total"])
    out["product_total_log"] = np.log1p(out["product_total"])
    grouped = out.groupby(["i", "k"], sort=False, observed=True)
    out["target_rca"] = grouped["rca_t"].shift(-horizon)
    out["target_year"] = grouped["t"].shift(-horizon)
    eligible = out["max_rca_history"].lt(0.25) & out["target_rca"].notna()
    result = out[eligible].copy()
    result["y"] = result["target_rca"].ge(1.0).astype(int)
    return result
