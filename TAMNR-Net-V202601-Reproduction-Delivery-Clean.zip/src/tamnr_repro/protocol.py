from __future__ import annotations

from dataclasses import dataclass
import json
from pathlib import Path
from typing import Iterable


@dataclass(frozen=True)
class FoldSpec:
    fold: int
    train_start: int
    train_end: int
    validation: int
    calibration: int
    test: tuple[int, ...]
    seed: int

    @property
    def first_test_anchor(self) -> int:
        return min(self.test)

    def training_anchors(self) -> tuple[int, ...]:
        return tuple(range(self.train_start, self.train_end + 1))

    def validate(self, horizon: int = 5) -> None:
        if not self.train_start <= self.train_end < self.validation < self.calibration:
            raise ValueError(f"Fold {self.fold}: non-chronological development partitions")
        if self.calibration + horizon > self.first_test_anchor:
            raise ValueError(
                f"Fold {self.fold}: calibration outcome is not observable before testing"
            )
        if self.validation + horizon > self.first_test_anchor:
            raise ValueError(
                f"Fold {self.fold}: validation outcome is not observable before testing"
            )


def load_config(path: str | Path) -> dict:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def strict_folds(config: dict) -> list[FoldSpec]:
    folds = []
    for row in config["protocol"]["folds"]:
        fold = FoldSpec(
            fold=int(row["fold"]),
            train_start=int(row["train_start"]),
            train_end=int(row["train_end"]),
            validation=int(row["validation"]),
            calibration=int(row["calibration"]),
            test=tuple(int(x) for x in row["test"]),
            seed=int(row["seed"]),
        )
        fold.validate(int(config["dataset"]["horizon"]))
        folds.append(fold)
    return folds


def outcome_observable(source_anchor: int, prediction_anchor: int, horizon: int = 5) -> bool:
    """Return whether a delayed label is known at the prediction anchor."""
    return source_anchor < prediction_anchor and source_anchor + horizon <= prediction_anchor


def assert_observable_sources(
    source_anchors: Iterable[int], prediction_anchor: int, horizon: int = 5
) -> None:
    invalid = [
        int(s)
        for s in source_anchors
        if not outcome_observable(int(s), int(prediction_anchor), horizon)
    ]
    if invalid:
        raise ValueError(
            f"Unobservable labels for prediction anchor {prediction_anchor}: {sorted(set(invalid))}"
        )
