from __future__ import annotations

import numpy as np
import pandas as pd


def country_block_paired_bootstrap(
    group_scores: pd.DataFrame,
    metric_a: str,
    metric_b: str,
    country_col: str = "i",
    repetitions: int = 10_000,
    seed: int = 20261005,
) -> dict[str, float | list[float]]:
    countries = group_scores[country_col].drop_duplicates().to_numpy()
    country_diff = (
        group_scores.assign(_diff=group_scores[metric_a] - group_scores[metric_b])
        .groupby(country_col, observed=True)["_diff"]
        .mean()
        .reindex(countries)
        .to_numpy(dtype=float)
    )
    observed = float(country_diff.mean())
    rng = np.random.default_rng(seed)
    boot = np.empty(repetitions, dtype=float)
    for idx in range(repetitions):
        selected = rng.integers(0, len(countries), size=len(countries))
        boot[idx] = country_diff[selected].mean()
    ci = np.quantile(boot, [0.025, 0.975])
    p_two = 2 * min(float((boot <= 0).mean()), float((boot >= 0).mean()))
    return {
        "mean_difference": observed,
        "ci95": [float(ci[0]), float(ci[1])],
        "p_two_sided": float(min(1.0, p_two)),
        "repetitions": int(repetitions),
        "countries": int(len(countries)),
    }


def holm_adjust(p_values: list[float]) -> list[float]:
    order = np.argsort(p_values)
    adjusted = np.empty(len(p_values), dtype=float)
    running = 0.0
    m = len(p_values)
    for rank, idx in enumerate(order):
        value = min(1.0, (m - rank) * float(p_values[idx]))
        running = max(running, value)
        adjusted[idx] = running
    return adjusted.tolist()
