from __future__ import annotations

import random

import numpy as np
import torch
from torch import nn


class TAMNRNet(nn.Module):
    def __init__(
        self,
        n_features: int,
        n_countries: int,
        n_products: int,
        n_years: int,
        hidden_dim: int = 128,
        embedding_dim: int = 16,
        year_embedding_dim: int = 4,
        dropout: float = 0.08,
        residual_scale: float = 0.010,
        temperature_min: float = 0.25,
        temperature_max: float = 4.0,
    ):
        super().__init__()
        self.country_emb = nn.Embedding(n_countries, embedding_dim)
        self.product_emb = nn.Embedding(n_products, embedding_dim)
        self.year_emb = nn.Embedding(n_years, year_embedding_dim)
        in_dim = n_features + 2 * embedding_dim + year_embedding_dim
        self.residual_tower = nn.Sequential(
            nn.Linear(in_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, hidden_dim),
            nn.LayerNorm(hidden_dim),
            nn.SiLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden_dim, 1),
        )
        self.memory_temperature = nn.Parameter(torch.tensor(1.0))
        self.memory_bias = nn.Parameter(torch.tensor(0.0))
        self.residual_scale = float(residual_scale)
        self.temperature_min = float(temperature_min)
        self.temperature_max = float(temperature_max)

    def forward(self, x_num, country_idx, product_idx, year_idx, memory_logit=None):
        if memory_logit is None:
            raise ValueError(
                "Pass the unstandardized temporal_memory_logit explicitly; "
                "x_num contains standardized residual-tower inputs."
            )
        joined = torch.cat(
            [
                x_num,
                self.country_emb(country_idx),
                self.product_emb(product_idx),
                self.year_emb(year_idx),
            ],
            dim=1,
        )
        residual = self.residual_tower(joined).squeeze(-1)
        temperature = self.memory_temperature.clamp(
            self.temperature_min, self.temperature_max
        )
        return temperature * memory_logit + self.memory_bias + self.residual_scale * residual


def weighted_bce(logits, y, positive_weight: float):
    weight = torch.as_tensor(positive_weight, dtype=logits.dtype, device=logits.device)
    return nn.functional.binary_cross_entropy_with_logits(logits, y, pos_weight=weight)


def ranknet_loss(positive_scores, negative_scores):
    return nn.functional.softplus(-(positive_scores - negative_scores)).mean()


def bpr_loss(positive_scores, negative_scores, model: nn.Module, l2: float = 1e-5):
    ranking = -nn.functional.logsigmoid(positive_scores - negative_scores).mean()
    penalty = sum((p.square().sum() for p in model.parameters()))
    return ranking + float(l2) * penalty


def seed_everything(seed: int) -> None:
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    torch.use_deterministic_algorithms(True, warn_only=True)
