from __future__ import annotations

import numpy as np
from sklearn.linear_model import LogisticRegression


class BetaCalibrator:
    """Binary beta calibration fitted on a temporally eligible calibration set."""

    def __init__(self, epsilon: float = 1e-12):
        self.epsilon = float(epsilon)
        self.model = LogisticRegression(C=1e6, solver="lbfgs", max_iter=2000)

    def _features(self, probabilities):
        p = np.clip(np.asarray(probabilities, dtype=float), self.epsilon, 1 - self.epsilon)
        return np.column_stack([np.log(p), -np.log1p(-p)])

    def fit(self, probabilities, y):
        self.model.fit(self._features(probabilities), np.asarray(y, dtype=int))
        return self

    def predict_proba(self, probabilities):
        return self.model.predict_proba(self._features(probabilities))[:, 1]
