from __future__ import annotations

import math

import numpy as np
import pandas as pd
from sklearn.metrics import (
    average_precision_score,
    brier_score_loss,
    f1_score,
    log_loss,
    precision_recall_curve,
    precision_score,
    recall_score,
    roc_auc_score,
)


def best_f1_threshold(y_true, scores) -> tuple[float, float]:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(scores, dtype=float)
    precision, recall, thresholds = precision_recall_curve(y, s)
    f1 = np.divide(
        2 * precision * recall,
        precision + recall,
        out=np.zeros_like(precision),
        where=(precision + recall) > 0,
    )
    if not len(thresholds):
        return 0.5, float(np.nanmax(f1))
    idx = int(np.nanargmax(f1[:-1]))
    return float(thresholds[idx]), float(f1[idx])


def _average_precision_at_k(y: np.ndarray, k: int) -> float:
    y = y[:k].astype(float)
    if not y.sum():
        return 0.0
    precision = np.cumsum(y) / np.arange(1, len(y) + 1)
    return float((precision * y).sum() / min(int(y.sum()), k))


def _ndcg_at_k(y: np.ndarray, k: int) -> float:
    y = y[:k].astype(float)
    discount = 1.0 / np.log2(np.arange(2, len(y) + 2))
    dcg = float((y * discount).sum())
    ideal = np.sort(y)[::-1]
    idcg = float((ideal * discount).sum())
    return dcg / idcg if idcg > 0 else 0.0


def group_ranking_metrics(
    frame: pd.DataFrame,
    score_col: str,
    k: int = 10,
    group_cols: tuple[str, ...] = ("i", "t"),
) -> tuple[dict[str, float], pd.DataFrame]:
    rows = []
    for keys, group in frame.groupby(list(group_cols), sort=False, observed=True):
        ordered = group.sort_values(score_col, ascending=False, kind="mergesort")
        top = ordered.head(k)
        denom = min(k, len(ordered))
        y = top["y"].to_numpy(dtype=int)
        key_tuple = keys if isinstance(keys, tuple) else (keys,)
        row = {name: value for name, value in zip(group_cols, key_tuple)}
        row.update(
            {
                "candidate_count": int(len(ordered)),
                "precision_at_10": float(y.sum() / denom) if denom else float("nan"),
                "map_at_10": _average_precision_at_k(y, k),
                "ndcg_at_10": _ndcg_at_k(y, k),
                "hit_at_10": float(y.sum() > 0),
                "recall_at_10": float(y.sum() / max(1, int(ordered["y"].sum()))),
            }
        )
        rows.append(row)
    groups = pd.DataFrame(rows)
    summary = {
        col: float(groups[col].mean())
        for col in [
            "precision_at_10",
            "map_at_10",
            "ndcg_at_10",
            "hit_at_10",
            "recall_at_10",
        ]
    }
    summary["groups"] = int(len(groups))
    summary["min_candidate_count"] = int(groups["candidate_count"].min()) if len(groups) else 0
    summary["mean_candidate_count"] = float(groups["candidate_count"].mean()) if len(groups) else float("nan")
    return summary, groups


def classification_metrics(y_true, scores, threshold: float) -> dict[str, float]:
    y = np.asarray(y_true, dtype=int)
    s = np.asarray(scores, dtype=float)
    pred = (s >= threshold).astype(int)
    clipped = np.clip(s, 1e-12, 1 - 1e-12)
    return {
        "threshold": float(threshold),
        "precision": float(precision_score(y, pred, zero_division=0)),
        "recall": float(recall_score(y, pred, zero_division=0)),
        "f1": float(f1_score(y, pred, zero_division=0)),
        "auc_pr": float(average_precision_score(y, s)),
        "auc_roc": float(roc_auc_score(y, s)),
        "brier": float(brier_score_loss(y, clipped)),
        "nll": float(log_loss(y, clipped, labels=[0, 1])),
    }


def expected_calibration_error(y_true, probabilities, bins: int = 15) -> float:
    y = np.asarray(y_true, dtype=float)
    p = np.clip(np.asarray(probabilities, dtype=float), 0, 1)
    edges = np.linspace(0, 1, bins + 1)
    total = len(y)
    ece = 0.0
    for left, right in zip(edges[:-1], edges[1:]):
        mask = (p >= left) & (p < right if right < 1 else p <= right)
        if mask.any():
            ece += mask.mean() * abs(float(y[mask].mean()) - float(p[mask].mean()))
    return float(ece)


def fold_mean_std(fold_metrics: pd.DataFrame, metric: str) -> tuple[float, float]:
    values = fold_metrics[metric].to_numpy(dtype=float)
    return float(values.mean()), float(values.std(ddof=1))
