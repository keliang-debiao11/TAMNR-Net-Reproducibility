from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np
import pandas as pd


def _smoothed_rate(frame: pd.DataFrame, keys, global_rate: float, smoothing: float) -> pd.Series:
    grouped = frame.groupby(keys, observed=True)["y"].agg(["sum", "count"])
    return (grouped["sum"] + smoothing * global_rate) / (grouped["count"] + smoothing)


@dataclass
class StrictTemporalMemoryEncoder:
    horizon: int = 5
    half_life_years: float = 5.0
    smoothing: float = 20.0
    neighbor_weight: float = 0.65
    prior_weight: float = 0.35
    country_product_weight: float = 0.50
    country_weight: float = 0.25
    product_weight: float = 0.25
    epsilon: float = 1e-6

    def fit(self, history: pd.DataFrame):
        required = {"i", "k", "t", "y"}
        missing = required.difference(history.columns)
        if missing:
            raise ValueError(f"Missing history columns: {sorted(missing)}")
        self.history_ = history[["i", "k", "t", "y"]].copy()
        self.history_["t"] = self.history_["t"].astype(int)
        self.history_["y"] = self.history_["y"].astype(float)
        self.global_rate_ = float(self.history_["y"].mean()) if len(self.history_) else 0.0
        self.country_prior_ = _smoothed_rate(
            self.history_, "i", self.global_rate_, self.smoothing
        )
        self.product_prior_ = _smoothed_rate(
            self.history_, "k", self.global_rate_, self.smoothing
        )
        self.cp_prior_ = _smoothed_rate(
            self.history_, ["i", "k"], self.global_rate_, self.smoothing
        )
        return self

    def _priors(self, target: pd.DataFrame) -> pd.DataFrame:
        out = target[["i", "k", "t"]].copy()
        out["country_activation_prior"] = (
            out["i"].map(self.country_prior_).fillna(self.global_rate_).astype(float)
        )
        out["product_activation_prior"] = (
            out["k"].map(self.product_prior_).fillna(self.global_rate_).astype(float)
        )
        cp_index = pd.MultiIndex.from_frame(out[["i", "k"]])
        out["country_product_activation_prior"] = pd.Series(
            self.cp_prior_.reindex(cp_index).to_numpy(), index=out.index
        ).fillna(self.global_rate_)
        out["prior_blend"] = (
            self.country_product_weight * out["country_product_activation_prior"]
            + self.country_weight * out["country_activation_prior"]
            + self.product_weight * out["product_activation_prior"]
        )
        return out

    def transform(self, target: pd.DataFrame) -> pd.DataFrame:
        if not hasattr(self, "history_"):
            raise RuntimeError("Call fit before transform")
        base = self._priors(target)
        base["temporal_neighbor_weighted"] = np.nan
        base["temporal_neighbor_coverage"] = 0.0
        for anchor in sorted(base["t"].astype(int).unique()):
            mask = base["t"].astype(int).eq(anchor)
            eligible = self.history_[
                (self.history_["t"] < anchor)
                & (self.history_["t"] + self.horizon <= anchor)
            ].copy()
            if not len(eligible):
                base.loc[mask, "temporal_neighbor_weighted"] = base.loc[mask, "prior_blend"]
                continue
            eligible["weight"] = np.power(
                2.0, -(anchor - eligible["t"].to_numpy(dtype=float)) / self.half_life_years
            )
            eligible["weighted_y"] = eligible["weight"] * eligible["y"]
            agg = eligible.groupby(["i", "k"], observed=True).agg(
                weighted_y=("weighted_y", "sum"),
                weight=("weight", "sum"),
            )
            idx = pd.MultiIndex.from_frame(base.loc[mask, ["i", "k"]])
            sums = agg.reindex(idx)
            denom = sums["weight"].to_numpy(dtype=float)
            numer = sums["weighted_y"].to_numpy(dtype=float)
            has = np.isfinite(denom) & (denom > 0)
            prior = base.loc[mask, "prior_blend"].to_numpy(dtype=float)
            neighbor = prior.copy()
            neighbor[has] = numer[has] / (denom[has] + self.epsilon)
            total_possible = float(
                np.power(
                    2.0,
                    -(anchor - np.sort(eligible["t"].unique()).astype(float))
                    / self.half_life_years,
                ).sum()
            )
            coverage = np.zeros(len(neighbor), dtype=float)
            coverage[has] = denom[has] / (total_possible + self.epsilon)
            base.loc[mask, "temporal_neighbor_weighted"] = neighbor
            base.loc[mask, "temporal_neighbor_coverage"] = coverage
        base["temporal_memory_score"] = (
            self.neighbor_weight * base["temporal_neighbor_weighted"].astype(float)
            + self.prior_weight * base["prior_blend"].astype(float)
        )
        for source, dest in [
            ("temporal_memory_score", "temporal_memory_logit"),
            ("country_product_activation_prior", "cp_prior_logit"),
            ("prior_blend", "prior_blend_logit"),
        ]:
            p = np.clip(base[source].to_numpy(dtype=float), self.epsilon, 1 - self.epsilon)
            base[dest] = np.log(p / (1 - p))
        return base


@dataclass
class RelaxedInterleavedMemoryEncoder(StrictTemporalMemoryEncoder):
    """Widest protocol used only for explicitly relaxed reproduction runs.

    The encoder uses same-country-product labels at fixed negative and positive
    anchor offsets when those source rows belong to the non-test training pool.
    It is intentionally not equivalent to strict prospective forecasting.
    """

    offsets: tuple[int, ...] = (-3, -2, -1, 1, 2, 3)

    def transform(self, target: pd.DataFrame) -> pd.DataFrame:
        if not hasattr(self, "history_"):
            raise RuntimeError("Call fit before transform")
        base = self._priors(target)
        weighted_sum = np.zeros(len(base), dtype=float)
        available_sum = np.zeros(len(base), dtype=float)
        keys = base[["i", "k", "t"]]
        for offset in self.offsets:
            source = self.history_[["i", "k", "t", "y"]].copy()
            source["t"] = source["t"] - int(offset)
            source = source.rename(columns={"y": "neighbor_y"})
            joined = keys.merge(source, on=["i", "k", "t"], how="left", sort=False)
            values = joined["neighbor_y"].fillna(0.0).to_numpy(dtype=float)
            available = joined["neighbor_y"].notna().to_numpy(dtype=float)
            weight = 1.0 / (abs(int(offset)) + 0.5)
            weighted_sum += weight * values
            available_sum += weight * available
        neighbor = np.divide(
            weighted_sum,
            np.maximum(available_sum, self.epsilon),
        )
        no_neighbor = available_sum <= 0
        prior = base["prior_blend"].to_numpy(dtype=float)
        neighbor[no_neighbor] = prior[no_neighbor]
        base["temporal_neighbor_weighted"] = neighbor
        base["temporal_neighbor_coverage"] = (available_sum > 0).astype(float)
        base["temporal_memory_score"] = self.neighbor_weight * neighbor + self.prior_weight * prior
        for source, dest in [
            ("temporal_memory_score", "temporal_memory_logit"),
            ("country_product_activation_prior", "cp_prior_logit"),
            ("prior_blend", "prior_blend_logit"),
        ]:
            p = np.clip(base[source].to_numpy(dtype=float), self.epsilon, 1 - self.epsilon)
            base[dest] = np.log(p / (1 - p))
        return base
