# Validation Record

Validation date: 2026-11-04

## Completed checks

- Python syntax compilation passed for every file under `src`, `scripts`, and
  `tests`.
- Six protocol tests passed: strict fold definitions, five-year outcome
  observability including the equality boundary, an instantiable paper memory
  configuration, the corrected Table 19/Table 8 numerical agreement, and
  relaxed-memory use of positive non-test offsets.
- `scripts/audit_reproduction.py --allow-mismatch` completed and generated
  `results/audit/audit.json` and `results/audit/audit.md`.
- Manuscript internal consistency is `PASS`; public-artifact reproduction and
  the combined audit remain `FAIL` because the current manuscript and public
  artifact are different experiments. This is an evidence result, not a
  software test failure.

## Not executed in this environment

End-to-end neural training was not run because the available Python runtime
does not contain PyTorch or scikit-learn and the exact HS92 V202501 processed
panel is not available locally. Install `requirements.txt` in a CUDA-compatible
environment and supply the immutable panel to run the strict or widest-relaxed
trainers.

No manuscript reference value was inserted into a computed result column.
